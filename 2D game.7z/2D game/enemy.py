import pygame
from settings import WIDTH, HEIGHT
from weapon import *
from particles import Particles, PhysObj
from math import *
from random import choice, randint
from os import getcwd, sep
from pickle import load

pygame.font.init()
hud_font = pygame.font.Font(None, int(640 / 50 + 480 / 50))
pygame.mixer.init()


class Enemy(pygame.sprite.Sprite):
    player_pos = (0, 0)

    def __init__(self, sc, group, speed, hp, sprite_name, angle, add=True):
        pygame.sprite.Sprite.__init__(self)
        self.sprite_name = getcwd() + sep + "sprites" + sep + "enemy" + sep + sprite_name
        self.based_speed = speed
        self.speed = speed * WIDTH / 800
        self.hp = hp
        self.armor = 0
        self.move = {"left": True, "right": True, "up": True, "down": True}
        self.delay = 0
        self.delay_max = 0
        self.bool_delay = True
        self.speedy = 0
        self.speedx = 0
        self.alarm = False
        self.angle = angle
        self.depth = 0  # Далбность видимости
        self.view_angle = 45  # Угол обзора
        self.move_to = False  # Эта переменная нужна для проверки наличия точки в которую надо перейти
        self.point = (0, 0)  # Координаты точки перехода
        self.image = pygame.image.load(self.sprite_name).convert()
        self.image.set_colorkey((255, 255, 255))
        self.rect = self.image.get_rect()
        if WIDTH != 800 and HEIGHT != 600:
            self.scaled_image = pygame.transform.scale(self.image, (
            int(self.rect.width * WIDTH / 800), int(self.rect.height * HEIGHT / 600 * 1.3)))
        else:
            self.scaled_image = self.image
        self.image = pygame.transform.rotate(self.scaled_image, -self.angle)
        self.dead = False  # Переменная для добавления новых врагов
        self.anim_num = 0
        self.anim_delay = 0  # Задержка для анимации
        self.last_damage = 0  # Переменная для анимации смерти и частиц
        self.sectors = []  # список секторов
        self.collided_sectors = []
        with open("settings.data", "rb") as f:
            self.save_sprite = load(f)["Сохранять спрайты"]
        self.sc = sc
        if add:
            self.add(group)

    def near_attack(self, obj):
        pass

    def long_attack(self, obj):
        if self.gip < 500 * int(WIDTH / 800):
            self.weapon.shoot(self.rect, (obj.rect.centerx, obj.rect.centery))

    def attack_delay(self):
        if not (self.bool_delay):
            self.delay += 100
            if self.delay >= self.delay_max:
                self.delay = 0
                self.bool_delay = True

    def new_point(self, coord):
        self.point = coord
        self.move_to = True

    def go_to(self):
        if self.rect.centerx in range(self.point[0] - 5, self.point[0] + 5) and self.rect.centery in range(
                self.point[1] - 5, self.point[1] + 5) or self.alarm:
            self.move_to = False
        else:
            self.speedy = ((self.point[1] - self.rect.centery) / self.gip) * self.speed
            self.speedx = ((self.point[0] - self.rect.centerx) / self.gip) * self.speed
            self.angle = degrees(acos((self.rect.centerx - self.point[0]) / self.gip))
            if self.point[1] > self.rect.centery:
                self.angle = 360 - self.angle
            if self.speedx > 0 and not (self.move["right"]):
                self.speedx = 0
            elif self.speedx < 0 and not (self.move["left"]):
                self.speedx = 0
            if self.speedy > 0 and not (self.move["down"]):
                self.speedy = 0
            elif self.speedy < 0 and not (self.move["up"]):
                self.speedy = 0
            self.rect.centery += self.speedy
            self.rect.centerx += self.speedx
            self.image = self.scaled_image
            self.rot = pygame.transform.rotate(self.image, -self.angle)
            self.image = self.rot
            self.rect = self.image.get_rect(center=(self.rect.center))

    def wall_sectors(self, wall, surface):
        for i in wall:
            if self.rect.centerx <= i.rect.centerx:
                if self.rect.centery <= i.rect.centery:
                    self.left_wall_dist = sqrt(
                        (self.rect.centerx - i.rect.topright[0]) ** 2 + (self.rect.centery - i.rect.topright[1]) ** 2)
                    self.left_wall_angle = degrees(acos((self.rect.centerx - i.rect.topright[0]) / self.left_wall_dist))
                    if i.rect.topleft[1] > self.rect.centery:
                        self.left_wall_angle = 360 - self.left_wall_angle
                    self.right_wall_dist = sqrt((self.rect.centerx - i.rect.bottomleft[0]) ** 2 + (
                                self.rect.centery - i.rect.bottomleft[1]) ** 2)
                    self.right_wall_angle = degrees(
                        acos((self.rect.centerx - i.rect.bottomleft[0]) / self.right_wall_dist))
                    self.right_wall_angle = 360 - self.right_wall_angle
                    self.nearest_dist = sqrt(
                        (self.rect.centerx - i.rect.topleft[0]) ** 2 + (self.rect.centery - i.rect.topleft[1]) ** 2)
                    self.nearest_angle = degrees(acos((self.rect.centerx - i.rect.topleft[0]) / self.nearest_dist))
                    if self.rect.centery < i.rect.top:
                        self.nearest_angle = 360 - self.nearest_angle
                else:
                    self.left_wall_dist = sqrt(
                        (self.rect.centerx - i.rect.topleft[0]) ** 2 + (self.rect.centery - i.rect.topleft[1]) ** 2)
                    self.left_wall_angle = degrees(acos((self.rect.centerx - i.rect.topleft[0]) / self.left_wall_dist))
                    self.right_wall_dist = sqrt((self.rect.centerx - i.rect.bottomright[0]) ** 2 + (
                                self.rect.centery - i.rect.bottomright[1]) ** 2)
                    self.right_wall_angle = degrees(
                        acos((self.rect.centerx - i.rect.bottomright[0]) / self.right_wall_dist))
                    if i.rect.bottomright[1] > self.rect.centery:
                        self.right_wall_angle = 360 - self.right_wall_angle
                    self.nearest_dist = sqrt((self.rect.centerx - i.rect.bottomleft[0]) ** 2 + (
                                self.rect.centery - i.rect.bottomleft[1]) ** 2)
                    self.nearest_angle = degrees(acos((self.rect.centerx - i.rect.bottomleft[0]) / self.nearest_dist))
                    if i.rect.bottom > self.rect.centery:
                        self.nearest_angle = 360 - self.nearest_angle
            else:
                if self.rect.centery <= i.rect.centery:
                    self.left_wall_dist = sqrt((self.rect.centerx - i.rect.bottomright[0]) ** 2 + (
                                self.rect.centery - i.rect.bottomright[1]) ** 2)
                    self.left_wall_angle = degrees(
                        acos((self.rect.centerx - i.rect.bottomright[0]) / self.left_wall_dist))
                    self.left_wall_angle = 360 - self.left_wall_angle
                    self.right_wall_dist = sqrt(
                        (self.rect.centerx - i.rect.topleft[0]) ** 2 + (self.rect.centery - i.rect.topleft[1]) ** 2)
                    self.right_wall_angle = degrees(
                        acos((self.rect.centerx - i.rect.topleft[0]) / self.right_wall_dist))
                    if i.rect.topleft[1] > self.rect.centery:
                        self.right_wall_angle = 360 - self.right_wall_angle
                    self.nearest_dist = sqrt(
                        (self.rect.centerx - i.rect.topright[0]) ** 2 + (self.rect.centery - i.rect.topright[1]) ** 2)
                    self.nearest_angle = degrees(acos((self.rect.centerx - i.rect.topright[0]) / self.nearest_dist))
                    if self.rect.centery < i.rect.top:
                        self.nearest_angle = 360 - self.nearest_angle
                else:
                    self.left_wall_dist = sqrt((self.rect.centerx - i.rect.bottomleft[0]) ** 2 + (
                                self.rect.centery - i.rect.bottomleft[1]) ** 2)
                    self.left_wall_angle = degrees(
                        acos((self.rect.centerx - i.rect.bottomleft[0]) / self.left_wall_dist))
                    if self.rect.centery < i.rect.bottom:
                        self.left_wall_angle = 360 - self.left_wall_angle
                    self.right_wall_dist = sqrt(
                        (self.rect.centerx - i.rect.topright[0]) ** 2 + (self.rect.centery - i.rect.topright[1]) ** 2)
                    self.right_wall_angle = degrees(
                        acos((self.rect.centerx - i.rect.topright[0]) / self.right_wall_dist))
                    self.nearest_dist = sqrt((self.rect.centerx - i.rect.bottomright[0]) ** 2 + (
                                self.rect.centery - i.rect.bottomright[1]) ** 2)
                    self.nearest_angle = degrees(acos((self.rect.centerx - i.rect.bottomright[0]) / self.nearest_dist))
                    if self.rect.centery < i.rect.bottom:
                        self.nearest_angle = 360 - self.nearest_angle
            if self.left_wall_dist > self.depth and self.right_wall_dist > self.depth:
                continue
            if len(self.sectors) > 0:
                for index in range(len(self.sectors)):
                    if self.nearest_dist < self.sectors[index][4]:
                        self.sectors.insert(index, (
                        self.left_wall_dist, self.left_wall_angle, self.right_wall_dist, self.right_wall_angle,
                        self.nearest_dist, self.nearest_angle))
                        break
                else:
                    self.sectors.append((self.left_wall_dist, self.left_wall_angle, self.right_wall_dist,
                                         self.right_wall_angle, self.nearest_dist, self.nearest_angle))
            else:
                self.sectors.append((self.left_wall_dist, self.left_wall_angle, self.right_wall_dist,
                                     self.right_wall_angle, self.nearest_dist, self.nearest_angle))
        self.sectors = self.sectors[::-1]
        # Отрисовка секторов
        """
        for i in self.sectors:
            pygame.draw.line(surface, (200, 100, 150), self.rect.center, (self.rect.centerx + i[0] * -cos(radians(i[1])), self.rect.centery + i[0] * -sin(radians(i[1]))))
            pygame.draw.line(surface, (200, 100, 150), self.rect.center, (self.rect.centerx + i[2] * -cos(radians(i[3])), self.rect.centery + i[2] * -sin(radians(i[3]))))
            pygame.draw.line(surface, (255, 0, 50), self.rect.center, (self.rect.centerx + i[4] * -cos(radians(i[5])), self.rect.centery + i[4] * -sin(radians(i[5]))))
        """

    def see(self, obj_coord, wall):
        if self.gip <= self.depth:
            try:
                self.obj_ray = (acos((self.rect.centerx - obj_coord[0]) / self.gip), asin(
                    (self.rect.centery - obj_coord[1]) / self.gip))  # Вычисление угла между игроком и врагом
                self.obj_angle = int(degrees(self.obj_ray[0])) if self.obj_ray[1] > 0 else 360 - int(
                    degrees(self.obj_ray[0]))
                pygame.draw.line(self.sc, (50, 255, 150), [*self.rect.center],
                                 [self.rect.centerx + int(self.gip) * -cos(self.obj_ray[0]),
                                  self.rect.centery + int(self.gip) * -sin(self.obj_ray[1])])
                self.left_angle = self.angle - self.view_angle // 2 if self.angle >= 30 else 360 - (
                            self.view_angle // 2 - self.angle)
                self.right_angle = self.angle + self.view_angle // 2 if self.angle <= 315 else 0 + (
                            (self.angle + self.view_angle // 2) - 360)
                pygame.draw.line(self.sc, (100, 200, 255), [*self.rect.center],
                                 [self.rect.centerx + self.depth * -cos(radians(self.left_angle)),
                                  self.rect.centery + self.depth * -sin(radians(self.left_angle))])
                pygame.draw.line(self.sc, (100, 200, 255), [*self.rect.center],
                                 [self.rect.centerx + self.depth * -cos(radians(self.right_angle)),
                                  self.rect.centery + self.depth * -sin(radians(self.right_angle))])
                # Проверка на то, видит ли враг игрока
                if self.left_angle > self.right_angle:
                    if self.obj_angle in range(int(self.left_angle), 360) or self.obj_angle in range(0,
                                                                                                     int(self.right_angle)):
                        for i in self.sectors:
                            if i[1] > i[3]:
                                if (self.obj_angle >= i[1] and self.obj_angle <= 360) or (
                                        (self.obj_angle >= 0 and self.obj_angle <= i[3]) and (
                                        self.gip > i[0] or self.gip > i[2])):
                                    break
                            else:
                                if self.obj_angle >= i[1] and self.obj_angle <= i[3] and (
                                        self.gip > i[0] or self.gip > i[2]):
                                    break
                        else:
                            self.alarm = True
                else:
                    if self.obj_angle in range(int(self.left_angle), int(self.right_angle)):
                        for i in range(len(self.sectors)):
                            if self.obj_angle in range(int(self.sectors[i][1]), int(self.sectors[i][3])) and (
                                    self.gip > self.sectors[i][0] or self.gip > self.sectors[i][2]):
                                break
                        else:
                            self.alarm = True

            except(ValueError):
                None
        else:
            self.alarm = False

    def cur_speed(self):
        if self.speedx - int(self.speedx) >= 0.5:
            self.speedx += 1
        if self.speedy - int(self.speedy) >= 0.5:
            self.speedx += 1
        if self.speedx > 0 and not (self.move["right"]):
            self.speedx = 0
        elif self.speedx < 0 and not (self.move["left"]):
            self.speedx = 0
        if self.speedy > 0 and not (self.move["down"]):
            self.speedy = 0
        elif self.speedy < 0 and not (self.move["up"]):
            self.speedy = 0

    def rotate(self):
        self.angle_diference = self.angle - self.obj_angle
        if self.angle_diference < 0:
            if self.angle_diference < -180:
                self.angle -= self.rotate_speed
            else:
                self.angle += self.rotate_speed
        elif self.angle_diference > 0:
            if self.angle_diference > 180:
                self.angle += self.rotate_speed
            else:
                self.angle -= self.rotate_speed
        if self.angle > 360:
            self.angle -= 360
        elif self.angle < 0:
            self.angle = 360 - abs(self.angle)
        if self.angle_diference in range(-10, 10):
            self.angle = self.obj_angle

    def blood(self, group):  # group - группа для частиц
        for i in range(self.last_damage // 10):
            self.blood_angle = self.angle + choice((-30, -15, 15, 30))
            if self.blood_angle > 360:
                self.blood_angle -= 360
            elif self.blood_angle < 0:
                self.blood_angle = 360 + self.blood_angle
            Particles(self.sc, group, "blood.png", self.rect.centerx, self.rect.centery, 5, self.blood_angle)


class Soldier(Enemy):
    alarm_sound = pygame.mixer.Sound(getcwd() + sep + "sound" + sep + "enemy_alarm" + sep + "soldier_alarm.wav")
    alarm_sound.set_volume(0.2)

    def __init__(self, x, y, angle, speed, sc, group, hp, weapon, sprite_name, add=True):
        Enemy.__init__(self, sc, group, speed, hp, sprite_name, angle, add)
        self.rect.centerx = x
        self.rect.centery = y
        self.delay_max = 2000
        self.weapon = weapon
        self.sound = Soldier.alarm_sound
        self.depth = int(800 * WIDTH / 800)
        self.view_angle = 90
        self.rotate_speed = 5  # Скорость поворота
        self.directory = getcwd() + sep + "sprites" + sep + "enemy" + sep + "soldier" + sep

    def update(self, obj, group, surface, wall):
        if not self.dead:
            self.weapon.step()
            try:
                if self.move_to:
                    self.gip = sqrt((self.point[0] - self.rect.centerx) ** 2 + (self.point[1] - self.rect.centery) ** 2)
                    self.go_to()
                if not self.move_to:
                    self.gip = sqrt(
                        (Enemy.player_pos[0] - self.rect.centerx) ** 2 + (Enemy.player_pos[1] - self.rect.centery) ** 2)
                    if not self.sectors and not self.alarm:
                        self.wall_sectors(wall, surface)
                    self.see((obj.rect.centerx, obj.rect.centery), wall)
                if self.alarm:
                    self.rotate()
                    if self.gip > 100:
                        self.speedy = ((Enemy.player_pos[1] - self.rect.centery) / self.gip) * self.speed
                        self.speedx = ((Enemy.player_pos[0] - self.rect.centerx) / self.gip) * self.speed
                        self.cur_speed()
                    else:
                        self.speedx, self.speedy = 0, 0
                    self.rect.centery += self.speedy
                    self.rect.centerx += self.speedx
                    self.image = self.scaled_image
                    self.rot = pygame.transform.rotate(self.image, -self.angle)
                    self.image = self.rot
                    self.rect = self.image.get_rect(center=(self.rect.center))
                    if self.angle_diference > -15 and self.angle_diference < 15:
                        self.long_attack(obj)
                    self.move = {"left": True, "right": True, "up": True, "down": True}
            except ZeroDivisionError:
                None
        else:
            self.death(group, surface)

    def death(self, group,
              surface):  # group - группа для частиц; surface - поверхность на которой будет отображаться спрайт после удаления
        if self.last_damage in range(0, 30):
            self.anim_name = self.directory + "death" + sep + "soldier_dead"
        elif self.last_damage in range(30, 999):
            if self.anim_num == 0 and self.anim_delay == 0:
                if randint(0, 1):
                    self.anim_name = self.directory + "death" + sep + "soldier_right_hand"
                    PhysObj(self.sc, group, "right_hand.png", self.rect.centerx, self.rect.centery, 7,
                            self.angle + 90 + randint(-20, 20), randint(1, 15))
                else:
                    self.anim_name = self.directory + "death" + sep + "soldier_left_leg"
                    PhysObj(self.sc, group, "left_leg.png", self.rect.centerx, self.rect.centery, 7,
                            self.angle - 180 + randint(-20, 20), randint(1, 15))
        self.anim_delay += 1
        if not self.anim_delay % 10:
            self.anim_num += 1
            if self.anim_num < 6:
                self.image = pygame.image.load(self.anim_name + str(self.anim_num) + ".png").convert()
                if WIDTH != 800 and HEIGHT != 600:
                    self.image = pygame.transform.scale(self.image, (
                    int(self.rect.width * WIDTH / 800), int(self.rect.height * HEIGHT / 600)))
                self.image.set_colorkey((255, 255, 255))
                self.image = pygame.transform.rotate(self.image, -self.angle)
                if self.anim_num == 5 and self.save_sprite > 0:
                    surface.blit(self.image, (self.rect.x, self.rect.y))
                    self.kill()
        if self.anim_num == 10:
            self.kill()
    def __copy__(self):
        return Soldier(self.rect.x, self.rect.y, self.angle, self.based_speed, self.sc, None, self.hp, self.weapon, self.sprite_name.split(sep)[-1], add=False)

class Dog(Enemy):
    def __init__(self, x, y, angle, speed, sc, group, hp, sprite_name, add=True):
        Enemy.__init__(self, sc, group, speed, hp, sprite_name, angle, add)
        self.rect.x = x
        self.rect.y = y
        self.delay_max = 5000
        self.depth = int(750 * WIDTH / 800)
        self.view_angle = 120
        self.rotate_speed = 5
        self.jump = False
        self.jump_dist = 0

    def update(self, obj, group, surface, wall):
        try:
            if not self.dead:
                if self.move_to:
                    self.gip = sqrt((self.point[0] - self.rect.centerx) ** 2 + (self.point[1] - self.rect.centery) ** 2)
                    self.go_to()
                if not self.move_to:
                    self.gip = sqrt(
                        (Enemy.player_pos[0] - self.rect.centerx) ** 2 + (Enemy.player_pos[1] - self.rect.centery) ** 2)
                    if not self.sectors and not self.alarm:
                        self.wall_sectors(wall, surface)
                    self.see((obj.rect.centerx, obj.rect.centery), wall)
                if self.alarm:
                    if not self.jump:
                        self.rotate()
                        # self.speedy = ((Enemy.player_pos[1] - self.rect.centery) / self.gip) * self.speed
                        # self.speedx = ((Enemy.player_pos[0] - self.rect.centerx) / self.gip) * self.speed
                        self.speedy = -self.speed * sin(radians(self.angle))
                        self.speedx = -self.speed * cos(radians(self.angle))
                        self.cur_speed()
                        self.rect.centery += self.speedy
                        self.rect.centerx += self.speedx
                        self.image = self.scaled_image
                        self.rot = pygame.transform.rotate(self.image, -self.angle)
                        self.image = self.rot
                        self.rect = self.image.get_rect(center=(self.rect.center))
                        self.text = hud_font.render(str(self.hp), True, (255, 255, 255))
                        self.sc.blit(self.text, (self.rect.centerx - 10, self.rect.centery - 37))
                        self.move = {"left": True, "right": True, "up": True, "down": True}
                        self.attack_delay()
                        if self.gip <= 70 and self.bool_delay:
                            self.jump = True
                    else:
                        if self.jump_dist < 100:
                            self.jump_dist += self.speed + 2
                            self.speedy = (-self.speed - 2) * sin(radians(self.angle))
                            self.speedx = (-self.speed - 2) * cos(radians(self.angle))
                            self.cur_speed()
                            self.rect.centery += self.speedy
                            self.rect.centerx += self.speedx
                            self.near_attack(obj)
                        else:
                            self.jump = False
                            self.jump_dist = 0
            else:
                self.death()
        except ZeroDivisionError:
            None

    def death(self):
        self.kill()

    def near_attack(self, obj):
        if self.bool_delay:
            if self.rect.centerx in range(Enemy.player_pos[0] - 20,
                                          Enemy.player_pos[0] + 20) and self.rect.centery in range(
                    Enemy.player_pos[1] - 20, Enemy.player_pos[1] + 20):
                if obj.armor:
                    obj.armor -= 20 // 3 * 2
                    if obj.armor < 0:
                        obj.hp -= 20 // 3 + abs(obj.armor)
                        obj.armor = 0
                    else:
                        obj.hp -= 20 // 3
                else:
                    obj.hp -= 20
                self.bool_delay = False
    def __copy__(self):
        return Dog(self.rect.x, self.rect.y, self.angle, self.based_speed, self.sc, None, self.hp, self.sprite_name.split(sep)[-1], add=False)
