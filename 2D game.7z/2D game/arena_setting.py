from pickle import dump
from settings import WIDTH, HEIGHT
with open("arena.data", "wb") as f:
    dump(("(WIDTH // 4, HEIGHT // 4, \"wall.png\")N(WIDTH - WIDTH // 4, HEIGHT // 4, \"wall.png\")N(WIDTH // 4, HEIGHT - HEIGHT // 4, \"wall.png\")N(WIDTH - WIDTH // 4, HEIGHT - HEIGHT // 4, \"wall.png\")",\
                    "(WIDTH // 2, -50, 270, (WIDTH // 2, 0))N(WIDTH + 50, HEIGHT // 2, 0, (WIDTH - 20, HEIGHT // 2))N\
                     (WIDTH // 2, HEIGHT + 50, 90, (WIDTH // 2, HEIGHT - 20))N(-50, HEIGHT // 2, 180, (20, HEIGHT // 2))", "(WIDTH // 2, HEIGHT // 2)"), f)
