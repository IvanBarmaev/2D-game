from pickle import dump
from enemy import *
from weapon import *
from item import *
from settings import WIDTH, HEIGHT


back1 = [(0.5, 0.1, "carpet.png"), (0.5, 0.2, "carpet.png")]
wall1 = [(0.6, 0.2, "wall.png"), (0.1, 0.2, "wall1.png")]
transition_data1 = [0.9, 0.0, 0.05, 1, 1]
player_pos1 = (0.05, 0.05)
enemy1 = [("Soldier", 0.5, 0.5, 270, "Pistol"), ("Soldier", 0.6, 0.5, 180, "Pistol"), ("Soldier", 0.6, 0.6, 180, "Pistol"), ("Soldier", 0.7, 0.5, 180, "Pistol")]
item1 = []
back2 = [(0.5, 0.1, "carpet.png"), (0.5, 0.2, "carpet.png")]
wall2 = [(0.2, 0.2, "wall2.png"), (0.8, 0.2, "wall2.png"), (0.2, 0.4, "wall2.png"), (0.8, 0.4, "wall2.png")]
transition_data2 = [0.1, 0.9, 0.8, 0.1, -1]
player_pos2 = (0.5, 0.05)
enemy2 = [("Soldier", 0.1, 0.6, 200, "Pistol"), ("Soldier", 0.9, 0.6, 290, "Pistol")]
item2 = []
with open("test_level.data", "wb") as f:
    dump([[wall1, back1, transition_data1, enemy1, item1, player_pos1], [wall2, back2, transition_data2, enemy2, item2, player_pos2]], f)

