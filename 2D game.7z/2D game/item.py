import pygame
from settings import WIDTH, HEIGHT
from some_tools import collide
from os import getcwd, sep

pygame.mixer.init()
class Item(pygame.sprite.Sprite):
    def __init__(self, x, y, sc, group, image, sound, add=True):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load(getcwd() + sep + "sprites" + sep + "items" + sep + image).convert()
        self.image.set_colorkey((255, 255, 255))
        self.rect = self.image.get_rect()
        if WIDTH != 800 and HEIGHT != 600:
            self.image = pygame.transform.scale(self.image, (int(self.rect.width * WIDTH / 800), int(self.rect.height * HEIGHT / 600 * 1.3)))
            self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.centery = y
        self.sound = pygame.mixer.Sound(getcwd() + sep + "sound" + sep + "item_sound" + sep + sound)
        self.sound.set_volume(0.2)
        if add:
            self.add(group)


class Heal(Item):
    def __init__(self, x, y, sc, group, image, sound, heal):
        Item.__init__(self, x, y, sc, group, image, sound)
        self.heal = heal
        
    def update(self, obj):
        if collide(self.rect, obj.rect):
            obj.hp += self.heal
            self.sound.play()
            self.kill()


class Bullets(Item):
    def __init__(self, x, y, sc, group, image, sound, num):
        Item.__init__(self, x, y, sc, group, image, sound)
        self.num = num

    def update(self, obj):
        if collide(self.rect, obj.rect):
            obj.weapon.bullets += self.num
            self.sound.play()
            self.kill()


class Armor(Item):
    def __init__(self, x, y, sc, group, image, sound, num):
        Item.__init__(self, x, y, sc, group, image, sound)
        self.num = num

    def update(self, obj):
        if collide(self.rect, obj.rect):
            obj.armor += self.num
            self.sound.play()
            self.kill()


class Weapon_Item(Item):
    def __init__(self, x, y, sc, group, image, sound, weapon):
        Item.__init__(self, x, y, sc, group, image, sound)
        self.weapon = weapon
    def update(self, obj):
        if collide(self.rect, obj.rect):
            if self.weapon in obj.weapon_list:
                obj.weapon_list[index(self.weapon)].bullet += 100
            else:
                obj.weapon_list.append(self.weapon)
            self.sound.play()
            self.kill()

