import pygame


def player_wall_collide(player, wall_group):
    """
    Функция для проверки стодкновений игрока и стен.
    Первый аргумент - игрок.
    Второй аргумент - группа стен.
    """
    hit_wall_list = pygame.sprite.spritecollide(player, wall_group, False)
    for i in hit_wall_list:
        if player.rect.right in range(i.rect.left, i.rect.right):
            player.move["right"] = False
            player.rect.x -= 1
        if player.rect.left in range(i.rect.left, i.rect.right):
            player.move["left"] = False
            player.rect.x += 1
        if player.rect.bottom in range(i.rect.top, i.rect.bottom):
            player.move["down"] = False
            player.rect.y -= 1
        if player.rect.top in range(i.rect.top, i.rect.bottom):
            player.move["up"] = False
            player.rect.y += 1

def enemy_wall_collide(enemy_group, wall_group):
    """
    Функция для проверки столкновений врагов и стен.
    Первый аргумент - группа врагов.
    Второй аргумент - группа стен.
    """
    for i in pygame.sprite.groupcollide(enemy_group, wall_group, False, False):
        for hit in pygame.sprite.spritecollide(i, wall_group, False):
            if i.rect.right in range(hit.rect.left, hit.rect.right):
                i.move["right"] = False
                i.rect.x -= 1
            if i.rect.left in range(hit.rect.left, i.rect.right):
                i.move["left"] = False
                i.rect.x += 1
            if i.rect.top in range(hit.rect.top, hit.rect.bottom):
                i.move["up"] = False
                i.rect.y += 1
            if i.rect.bottom in range(hit.rect.top, hit.rect.bottom):
                i.move["down"] = False
                i.rect.y -= 1

def bullet_collide(bullet_group, enemy_group, particles_group):
    killed = 0
    for hit in pygame.sprite.groupcollide(bullet_group, enemy_group, False, False):
        for i in pygame.sprite.spritecollide(hit, enemy_group, False):
            if i.anim_num <= 3:
                hit.collide(i)
                i.last_damage = hit.damage
                i.blood(particles_group)
            i.alarm = True
            if i.hp <= 0 and not i.dead:
                i.dead = True
                killed += 1
    return killed

def particles_collide(particles_group, wall_group):
    for hit in pygame.sprite.groupcollide(particles_group, wall_group, False, False):
        for i in pygame.sprite.spritecollide(hit, wall_group, False):
            hit.collide(i)

def surf_shift(coord_list, shift):
    if not coord_list:
        if shift > 2:
            shift = 2
        coord_list.append((-shift, -shift))
        coord_list.append((0, -shift))
        coord_list.append((shift, -shift))
        coord_list.append((shift, 0))
        coord_list.append((shift, shift))
        coord_list.append((0, shift))
        coord_list.append((-shift, shift))

def surf_rotate(angle, angle_limit, key):
    if key[pygame.K_w] or key[pygame.K_d] or key[pygame.K_s] or key[pygame.K_a]:
        angle += angle_limit / 20
        if abs(angle) >= abs(angle_limit):
            angle = angle_limit - angle_limit / 10
            angle_limit *= -1
    elif angle != 0:
        if abs(angle_limit - angle) > abs(angle_limit):
            angle -= (angle_limit / 20) * -1
        else:
            angle -= angle_limit / 20
        if abs(angle) <= 0.1:
            angle = 0
    return (angle, angle_limit)
    
            
