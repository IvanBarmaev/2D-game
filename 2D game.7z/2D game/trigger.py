import pygame
from item import *
from enemy import *
from some_tools import *
from os import getcwd, sep

pygame.mixer.init()
pygame.font.init()
t = pygame.font.SysFont("Lucida Console", 4).render("", False, (0, 0, 0))
class Trigger(pygame.sprite.Sprite):
    def __init__(self, x, y, width, height, sc, group):
        pygame.sprite.Sprite.__init__(self)
        self.rect = pygame.Rect(x, y, width, height)
        self.sc = sc
        self.group = group

class Item_Trigger(Trigger):
    def __init__(self, x, y, width, height, sc, group, item_image, item_sound, num, item_x, item_y):
        Trigger.__init__(self, x, y, width, height, sc, group)
        self.item_image = item_image
        self.item_sound = item_sound
        self.num = num
        self.item_y = item_y
        self.item_x = item_x
        
    def update(self, obj_rect):
       if collide(obj_rect, self.rect):
            if self.item_image == "heal.png":
               Heal(self.item_x, self.item_y, self.sc, self.group, self.item_image, self.item_sound, self.num)
            elif self.item_image == "bullets_box.png":
                Bullets(self.item_x, self.item_y, self.sc, self.group, self.item_image, self.item_sound, self.num)
            self.kill()

class Enemy_Trigger(Trigger):
    def __init__(self, x, y, width, height, sc, group, sound, enemy_x, enemy_y, num, line):
        Trigger.__init__(self, x, y, width, height, sc, group)
        self.enemy_x = enemy_x
        self.enemy_y = enemy_y
        self.num = num
        self.line = line

    def update(self, obj_rect):
        if collide(obj_rect, self.rect):
            if self.line == "x":
                for i in range(self.num):
                    Soldier(self.enemy_x + 50 * i, self.enemy_y, 3, self.sc, self.group)
            elif self.line == "y":
                for i in range(self.num):
                    Soldier(self.enemy_x, self.enemy_y + 50 * i, 3, self.sc, self.group)
            self.kill()


class Message(pygame.sprite.Sprite):
    surf_text = ""
    render_text = t
    render_text_rect = t.get_rect()
    def __init__(self, sc, group, x, y, width, height, text, size, t):
        pygame.sprite.Sprite.__init__(self)
        self.rect = pygame.Rect(x, y, width, height)
        self.sc = sc
        group.add(self)
        self.text = text
        self.activity = False
        self.time = 0
        self.t = t
        self.font = pygame.font.SysFont("Lucida Console", size)

    def update(self, obj_rect):
        if not self.activity and collide(obj_rect, self.rect):
            self.activity = True
            Message.surf_text = self.text
            Message.render_text = self.font.render(Message.surf_text, True, (150, 255, 20))
            Message.render_text_rect = Message.render_text.get_rect()
        elif self.activity:
            self.sc.blit(Message.render_text, (WIDTH // 2 - Message.render_text_rect.width // 2, HEIGHT - Message.render_text_rect.height - 20))
            self.time += self.t
            if self.time > 5:
                self.activity = False
                self.time = 0
            
