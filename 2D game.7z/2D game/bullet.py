import pygame
from settings import WIDTH, HEIGHT
from math import sqrt
from os import getcwd, sep

class a_bullet(pygame.sprite.Sprite):
    def __init__(self, x, y, speedx, speedy, damage, sc, group, image):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load(getcwd() + sep + "sprites" + sep + "bullets" + sep + image).convert()
        self.image.set_colorkey((255, 255, 255))
        self.rect = self.image.get_rect()
        if WIDTH != 800 and HEIGHT != 600:
            self.image = pygame.transform.scale(self.image, (int(self.rect.width * WIDTH / 800), int(self.rect.height * HEIGHT / 600 * 1.3)))
            self.rect = self.image.get_rect(center=(x, y))
        self.rect.x = x
        self.rect.y = y
        self.x, self.y = x, y
        self.speedy = speedy * WIDTH / 800
        self.speedx = speedx * WIDTH / 800
        self.lenght = 0
        self.damage = damage
        self.exp = False # Эта переменная для класса Rocket
        self.add(group)

    def collide(self, obj):
        if obj.armor:
            obj.armor -= self.damage // 3 * 2
            if obj.armor < 0:
                obj.hp -= self.damage // 3 + abs(obj.armor)
                obj.armor = 0
            else:
                obj.hp -= self.damage // 3
        else:
            obj.hp -= self.damage
        obj.last_damage = self.damage
        self.kill()

    def wall_collide(self):
        self.kill()

class Bullet(a_bullet):
    def __init__(self, x, y, speedx, speedy, damage, sc, group, image):
        a_bullet.__init__(self, x, y, speedx, speedy, damage, sc, group, image)
    def update(self):
        self.x += self.speedx
        self.y += self.speedy
        self.rect.x, self.rect.y = round(self.x), round(self.y)
        self.lenght += abs(self.speedx) + abs(self.speedy)
        if self.lenght >= int(1500 * WIDTH / 800):
            self.kill()


class Rocket(a_bullet):
    def __init__(self, x, y, speed, speedx, speedy, sc, group, damage, image, angle):
        a_bullet.__init__(self, x, y, speedx, speedy, damage, sc, group, image)
        self.image = pygame.transform.rotate(self.image, -angle)
        self.num = 0
        self.explosion_delay = 0
        self.sound = pygame.mixer.Sound(getcwd() + sep + "sound" + sep + "weapon_sound" + sep + "explosion.wav")
        self.sound.set_volume(0.3)
        self.exp = False
        self.obj_list = []  #список для объектов, которые столкнулись с спрайтом

    def update(self):
        self.x += self.speedx
        self.y += self.speedy
        self.rect.centerx, self.rect.centery = round(self.x), round(self.y)
        self.lenght += abs(self.speedx) + abs(self.speedy)
        if self.lenght >= int(700 * WIDTH / 800) or self.exp:
            self.explosion()
        self.key = pygame.key.get_pressed()

    def explosion(self):
        self.speedy, self.speedx = 0, 0
        if self.explosion_delay == 0:
            self.sound.play()
        self.image = pygame.image.load(getcwd() + sep + "sprites" + sep + "explosion" + sep + str(self.num) + "_explosion.png").convert()
        self.rect = self.image.get_rect(center=(self.rect.centerx, self.rect.centery))
        if WIDTH != 800:
            self.image = pygame.transform.scale(self.image, (int(self.rect.width * WIDTH / 800), int(self.rect.height * HEIGHT / 600 * 1.3)))
            self.rect = self.image.get_rect(center=(self.rect.centerx, self.rect.centery))
        self.image.set_colorkey((255, 255, 255))
        if self.explosion_delay == 500 and self.num == 1:
            for i in self.obj_list:
                self.dist = sqrt((i.rect.centerx - self.rect.centerx) ** 2 + (i.rect.centery - self.rect.centery) ** 2)
                i.hp -= int((self.rect.width - int(self.dist)) * 1.5)
                i.last_damage = int((self.rect.width - int(self.dist)) * 1.5)
        self.explosion_delay += 100
        if self.explosion_delay % 500 == 0:
            self.num += 1
        if self.num > 8:
            self.kill()

    def collide(self, obj):
        if not self.exp:
            self.explosion()
            self.exp = True
        if self.num == 0 and obj not in self.obj_list:
            self.obj_list.append(obj)

    def wall_collide(self):
        self.exp = True
