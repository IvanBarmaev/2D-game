import pygame
from os import getcwd, sep, listdir
from enemy import *
from weapon import *
from settings import *
from wall import *
from item import *
from button import *
from enter import EnterSurf
from math import sqrt, acos, degrees
from pickle import dump

def new_arena():
    player_pos = None, None
    player_pos_choice = False
    wall_pos_choice = False
    back_pos_choice = False
    enemy_spawn_choice = False
    item_choice = False
    delete = False
    markup = False
    save = False
    
    message_font = pygame.font.SysFont("Arial", WIDTH // 50)
    enemy_spawn = []
    wall_coord = []
    back_coord = []
    level_x, level_y = 0, 0
    item_spawn = 0, 0
    scaled = 1
    
    main_surf = pygame.Surface((WIDTH - WIDTH // 4, HEIGHT - HEIGHT // 6))
    level_surf = pygame.Surface((WIDTH, HEIGHT))
    back_surf = pygame.Surface((WIDTH, HEIGHT))
    sprite_surf = pygame.Surface((WIDTH, HEIGHT))
    message_surf = pygame.Surface((WIDTH - WIDTH // 4, int(HEIGHT * 0.05)))
    coord_surf = pygame.Surface((WIDTH // 4, int(HEIGHT * 0.05)))
    sprite_surf.fill((1, 1, 1))
    sprite_surf.set_colorkey((1, 1, 1))

    player = pygame.image.load(getcwd() + sep + "sprites" + sep + "player.png").convert()
    player_rect = player.get_rect()
    if WIDTH != 800 and HEIGHT != 600:
        player = pygame.transform.scale(player, (int(player_rect.width * WIDTH / 800), int(player_rect.height * HEIGHT / 600 * 1.3)))
    player_rect = player.get_rect()
    player.set_colorkey((255, 255, 255))
    player_half_width, player_half_height = player_rect.width // 2, player_rect.height // 2
    active_sprite = None
    active_sprite_surf = None
    del player_rect
    
    message_surf.fill((40, 40, 40))
    coord_surf.fill((40, 40, 40))
    level_surf.fill((0, 0, 0))
    level_txt = pygame.font.SysFont("Arial", WIDTH // 50)
    main_surf.blit(level_surf, (level_x, level_y))
    sc.blit(main_surf, (0, HEIGHT // 6))
    
    player_pos_button = Button(sc, int(WIDTH * 0.77), int(HEIGHT * 0.08), "Позиция игрока", WIDTH // 50)
    button_height = player_pos_button.rect.height
    wall_pos_button = Button(sc, int(WIDTH * 0.77), int(HEIGHT * 0.16), "Добавить стену", WIDTH // 50)
    back_pos_button = Button(sc, int(WIDTH * 0.77), int(HEIGHT * 0.24), "Добавить фоновый спрайт", WIDTH // 70, height=button_height)
    enemy_spawn_button = Button(sc, int(WIDTH * 0.77), int(HEIGHT * 0.32), "Добавить точку появления врагов", WIDTH // 85, height=button_height)
    item_button = Button(sc, int(WIDTH * 0.77), int(HEIGHT * 0.40), "Добавить ", WIDTH // 50)
    delete_button = Button(sc, int(WIDTH * 0.77), int(HEIGHT * 0.48), "Удалить", WIDTH // 50)
    markup_button = Button(sc, int(WIDTH * 0.77), int(HEIGHT * 0.56), "Включить разметку", WIDTH // 50)
    reset_button = Button(sc, int(WIDTH * 0.77), int(HEIGHT * 0.64), "Сброс координат", WIDTH // 50)
    save_button = Button(sc, int(WIDTH * 0.77), int(HEIGHT * 0.72), "Сохранить", WIDTH // 50)
    quit_button = Button(sc, int(WIDTH * 0.77), int(HEIGHT * 0.8), "Выйти", WIDTH // 50)
    wall_list = ListBox(sc, int(WIDTH * 0.04), int(HEIGHT * 0.04), [x.split(".")[0] for x in listdir(getcwd() + sep + "sprites" + sep + "terrain" + sep + "walls" + sep)], WIDTH // 50, "walls")  #В description добавлено название папки со спрайтами стены
    back_list = ListBox(sc, int(WIDTH * 0.04), int(HEIGHT * 0.04), [x.split(".")[0] for x in listdir(getcwd() + sep + "sprites" + sep + "terrain" + sep + "background" + sep)], WIDTH // 50, "background")  #Здесь папка со спрайтами фонов
    buttons = [player_pos_button, wall_pos_button, back_pos_button, enemy_spawn_button, item_button, delete_button, markup_button, reset_button, save_button, quit_button]
    quit_surf = YesNoSurface(sc, WIDTH // 2 - (WIDTH // 6) // 2, HEIGHT // 2 - (HEIGHT // 4) // 2, WIDTH // 6, HEIGHT // 4, "Вы уверены, что хотите выйти?", WIDTH // 45)
    save_surf = EnterSurf(sc, WIDTH - WIDTH // 2 - WIDTH // 8, HEIGHT - HEIGHT // 2 - HEIGHT // 8, WIDTH // 3, HEIGHT // 3, "Введите название карты", WIDTH // 45)
    
    def buttons_render():
        nonlocal buttons
        if ListBox.active_box:
            for i in buttons + [ListBox.active_box]:
                i.render()
        else:
            for i in buttons:
                i.render()

    def surface_render():
        nonlocal sprite_surf, back_surf, level_surf, wall_coord, back_coord, item_spawn, player_pos
        sprite_surf.fill((1, 1, 1))
        sprite_surf.set_colorkey((1, 1, 1))
        back_surf.fill((0, 0, 0))
        level_surf.fill((0, 0, 0))
        for i in wall_coord:
            sprite = pygame.image.load(getcwd() + sep + "sprites" + sep + "terrain" + sep + "walls" + sep + i[2]).convert()
            sprite.set_colorkey((255, 255, 255))
            sprite_rect = sprite.get_rect()
            if WIDTH != 800:
                sprite = pygame.transform.scale(sprite, (int(sprite_rect.width * WIDTH / 800), int(sprite_rect.height * HEIGHT / 600 * 1.3)))
                sprite_rect = sprite.get_rect()
            sprite_surf.blit(sprite, (int(WIDTH * i[0]), int(HEIGHT * i[1])))
        for i in back_coord:
            sprite = pygame.image.load(getcwd() + sep + "sprites" + sep + "terrain" + sep + "background" + sep + i[2]).convert()
            sprite.set_colorkey((255, 255, 255))
            sprite_rect = sprite.get_rect()
            if WIDTH != 800:
                sprite = pygame.transform.scale(sprite, (int(sprite_rect.width * WIDTH / 800), int(sprite_rect.height * HEIGHT / 600 * 1.3)))
                sprite_rect = sprite.get_rect()
            back_surf.blit(sprite, (int(WIDTH * i[0]), int(HEIGHT * i[1])))
    
    def save_arena():
        nonlocal wall_coord, back_coord, enemy_spawn, player_pos, save
        save_list = []
        text = ''
        for i in wall_coord:
            text += "(" + str(i[0]) + " * WIDTH, " + str(i[1]) + " * HEIGHT, " + "'" + i[2] + "'" + ")N"
        save_list.append(text)
        back = []
        for i in back_coord:
            back.append((i[0], i[1], i[2]))
        save_list.append(back)
        del back
        text = ''
        for i in enemy_spawn:
            text += "(" + i + ")N"
        text = text[0:-1]
        save_list.append(text)
        text = str(player_pos[0] / WIDTH) + " * WIDTH, " + str(player_pos[1] / HEIGHT) + " * HEIGHT"
        save_list.append(text)
        with open(getcwd() + sep + "arenas" + sep + save_surf.enter.text + ".data", "wb") as f:
            dump(save_list, f)
        save = False
            
    buttons_render()
    while True:
        if not YesNoSurface.active_surf and not save:
            for i in pygame.event.get():
                if i.type == pygame.QUIT:
                    pygame.quit()
                if i.type == pygame.MOUSEBUTTONDOWN:
                    pos = pygame.mouse.get_pos()
                    pressed = pygame.mouse.get_pressed()
                    if pressed[0]:
                        if pos[0] in range(0, WIDTH - WIDTH // 4) and pos[1] in range(HEIGHT // 6 - int(HEIGHT * 0.05), HEIGHT - int(HEIGHT * 0.05)):
                            coord = int((pos[0] - level_x) / scaled), int((pos[1] - level_y - HEIGHT // 6 + int(HEIGHT * 0.05)) / scaled)
                            if ListBox.active_box and ListBox.active_box.activated:
                                if ListBox.active_box.in_rect(*pos):
                                    ListBox.active_box.txt = ListBox.active_box.all_txt[ListBox.active_box.text.index(ListBox.active_box.in_rect(*pos))]
                                    active_sprite = pygame.image.load(getcwd() + sep + "sprites" + sep + "terrain" + sep + ListBox.active_box.description + sep +
                                                                      ListBox.active_box.text[ListBox.active_box.all_txt.index(ListBox.active_box.txt)] + ".png").convert()
                                    if WIDTH != 800:
                                        active_rect = active_sprite.get_rect()
                                        active_sprite = pygame.transform.scale(active_sprite, (int(active_rect.width * WIDTH / 800), int(active_rect.height * HEIGHT / 600 * 1.3)))
                                        del active_rect
                                    active_sprite.set_colorkey((255, 255, 255))
                                    active_half_width, active_half_height = active_sprite.get_rect().width // 2, active_sprite.get_rect().height // 2
                                ListBox.active_box.activated = False
                                sc.fill((0, 0, 0))
                                buttons_render()
                            elif player_pos_choice:
                                player_pos_choice = False
                                active_sprite = None
                                if coord[0] in range(0, WIDTH) and coord[1] in range(0, HEIGHT):
                                    player_pos = coord
                                    message_surf.fill((40, 40, 40))
                                    message_surf.blit(message_font.render("Координаты игрока:" + str(player_pos[0]) + ", "+ str(player_pos[1]), True, (255, 250, 10)), (int(WIDTH * 0.01), 0))
                                else:
                                    message_surf.fill((40, 40, 40))
                                    message_surf.blit(message_font.render("Координаты вне диапазона карты", True, (255, 250, 10)), (int(WIDTH * 0.01), 0))
                            elif wall_pos_choice:
                                if coord[0] in range(0, WIDTH) and coord[1] in range(0, HEIGHT):
                                    sprite_surf.blit(active_sprite, (coord[0] - active_half_width, coord[1] - active_half_height))
                                    wall_coord.append(((coord[0] - active_sprite.get_rect().width // 2) / WIDTH, (coord[1] - active_sprite.get_rect().height // 2) / HEIGHT, wall_list.text[wall_list.all_txt.index(wall_list.txt)] + ".png"))
                                    sprite_surf.set_colorkey((1, 1, 1))
                                    message_surf.fill((40, 40, 40))
                                else:
                                    message_surf.fill((40, 40, 40))
                                    message_surf.blit(message_font.render("Координаты вне диапазона карты", True, (255, 250, 10)), (int(WIDTH * 0.01), 0))
                            elif back_pos_choice:
                                if coord[0] in range(0, WIDTH) and coord[1] in range(0, HEIGHT):
                                    back_surf.blit(active_sprite, (coord[0] - active_half_width, coord[1] - active_half_height))
                                    back_coord.append(((coord[0] - active_sprite.get_rect().width // 2) / WIDTH, (coord[1] - active_sprite.get_rect().height // 2) / HEIGHT, back_list.text[back_list.all_txt.index(back_list.txt)] + ".png"))
                                    
                                else:
                                    message_surf.fill((40, 40, 40))
                                    message_surf.blit(message_font.render("Координаты вне диапазона карты", True, (255, 250, 10)), (int(WIDTH * 0.01), 0))
                            elif enemy_spawn_choice:
                                if pos[0] in range(level_x, level_x + int(WIDTH * scaled)) and pos[1] in range(level_y + HEIGHT // 6 - WIDTH // 40, level_y + HEIGHT // 6 - WIDTH // 40 + int(HEIGHT * scaled)):
                                    if coord[0] in range(0, WIDTH // 20) and coord[1] in range(HEIGHT // 10, HEIGHT - HEIGHT // 10):
                                        enemy_spawn.append(("WIDTH * -0.01, HEIGHT * " + str(coord[1] / HEIGHT) + ", 180, (int(WIDTH * " + str(coord[0] / WIDTH) + "), int(HEIGHT * " + str(coord[1] / HEIGHT) + "))"))
                                    elif coord[0] in range(WIDTH - WIDTH // 20, WIDTH) and coord[1] in range(HEIGHT // 10, HEIGHT - HEIGHT // 10):
                                        enemy_spawn.append(("WIDTH * 1.01, HEIGHT * " + str(coord[1] / HEIGHT) + ", 0, (int(WIDTH * " +str(coord[0] / WIDTH) + "), int(HEIGHT * " + str(coord[1] / HEIGHT) + "))"))
                                    elif coord[0] in range(WIDTH // 20, WIDTH - WIDTH // 20) and coord[1] in range(0, HEIGHT // 10):
                                        enemy_spawn.append(("WIDTH * " + str(coord[0] / WIDTH) + ", HEIGHT * -0.01, 270, (int(WIDTH * " + str(coord[0] / WIDTH) + "), int(HEIGHT * " + str(coord[1] / HEIGHT) + "))"))
                                    elif coord[0] in range(WIDTH // 20, WIDTH - WIDTH // 20) and coord[1] in range(HEIGHT - HEIGHT // 10, HEIGHT):
                                        enemy_spawn.append(("WIDTH * " + str(coord[0] / WIDTH) + ", HEIGHT * 1.01, 90, (int(WIDTH * " + str(coord[0] / WIDTH) + "), int(HEIGHT * " + str(coord[1] / HEIGHT) + "))"))
                                    elif coord[0] in range(0, WIDTH // 20) and coord[1] in range(0, HEIGHT // 10):
                                        gip = sqrt((WIDTH * -0.05 - coord[0]) ** 2 + (HEIGHT * -0.01 - coord[1]) ** 2)
                                        enemy_spawn.append(("WIDTH * -0.05, HEIGHT * -0.01, " + str(360 - degrees(acos((WIDTH * -0.05 - coord[0]) / gip))) + ", (int(WIDTH * " + str(coord[0] / WIDTH) + "), int(HEIGHT * " + str(coord[1] / HEIGHT) + "))"))
                                    elif coord[0] in range(0, WIDTH // 20) and coord[1] in range(HEIGHT - HEIGHT // 10, HEIGHT):
                                        gip = sqrt((WIDTH * -0.05 - coord[0]) ** 2 + (HEIGHT * 1.01 - coord[1]) ** 2)
                                        enemy_spawn.append(("WIDTH * -0.05, HEIGHT * 1.01, " + str(degrees(acos((WIDTH * -0.05 - coord[0]) / gip))) + ", (int(WIDTH * " + str(coord[0] / WIDTH) + "), int(HEIGHT * " + str(coord[1] / HEIGHT) + "))"))
                                    elif coord[0] in range(WIDTH - WIDTH // 20, WIDTH) and coord[1] in range(HEIGHT - HEIGHT // 10, HEIGHT):
                                        gip = sqrt((WIDTH * 1.05 - coord[0]) ** 2 + (HEIGHT * 1.01 - coord[1]) ** 2)
                                        enemy_spawn.append(("WIDTH * 1.05, HEIGHT * 1.01, " + str(degrees(acos((WIDTH * 1.05 - coord[0] )/ gip))) + ", (int(WIDTH * " + str( coord[0] / WIDTH) + "), int(HEIGHT * " + str(coord[1] / HEIGHT) + "))"))
                                    elif coord[0] in range(WIDTH - WIDTH // 20, WIDTH) and coord[1] in range(0, HEIGHT // 10):
                                        gip = sqrt((WIDTH * 1.05 - coord[0]) ** 2 + (HEIGHT * -0.01 - coord[1]) ** 2)
                                        enemy_spawn.append(("WIDTH * 1.05, HEIGHT * -0.01, " + str(360 - degrees(acos((WIDTH * 1.05 - coord[0]) / gip))) + ", (int(WIDTH * " + str(coord[0] / WIDTH) + "), int(HEIGHT * " + str(coord[1] / HEIGHT) + "))"))
                                    if len(enemy_spawn) and (not coord[0] in range(WIDTH // 20, WIDTH - WIDTH // 20) or not coord[1] in range(HEIGHT // 10, HEIGHT - HEIGHT // 10)):
                                        message_surf.fill((40, 40, 40))
                                        message_surf.blit(message_font.render(("Координаты: " + str(coord[0]) + ", " + str(coord[1]) + ". Угол: " + enemy_spawn[-1].split(",")[2]), True, (255, 250, 10)), (int(WIDTH * 0.01), 0))
                            elif item_choice:
                                if coord[0] in range(0, WIDTH) and coord[1] in range(0, HEIGHT):
                                    item_spawn = coord
                                    item_choice = False
                                    message_surf.fill((40, 40, 40))
                                    message_surf.blit(message_font.render(("Координаты появления предметов: " + str(coord[0]) + ", " + str(coord[1])), True, (255, 250, 10)), (int(WIDTH * 0.01), 0))
                                else:
                                    message_surf.fill((40, 40, 40))
                                    message_surf.blit((message_font.render("Координаты вне диапозона карты", True, (255, 250, 10))), (int(WIDTH * 0.01), 0))
                            elif delete:
                                for i in wall_coord:
                                    sprite = pygame.image.load(getcwd() + sep + "sprites" + sep + "terrain" + sep + "walls" + sep + i[2]).convert()
                                    rect = sprite.get_rect()
                                    if WIDTH != 800:
                                        sprite = pygame.transform.scale(sprite, (int(rect.width * WIDTH / 800), int(rect.height * HEIGHT / 600 * 1.3)))
                                        rect = sprite.get_rect()
                                    if coord[0] in range(int(WIDTH * i[0]), int(WIDTH * i[0] + rect.width)) and coord[1] in range(int(HEIGHT * i[1]), int((HEIGHT * i[1] + rect.height))):
                                        wall_coord.remove(i)
                                        surface_render()
                                        break
                                else:
                                    for i in back_coord:
                                        sprite = pygame.image.load(getcwd() + sep + "sprites" + sep + "terrain" + sep + "background" + sep + i[2]).convert()
                                        rect = sprite.get_rect()
                                        if WIDTH != 800:
                                            sprite = pygame.transform.scale(sprite, (int(rect.width * WIDTH / 800), int(rect.height * HEIGHT / 600 * 1.3)))
                                            rect = sprite.get_rect()
                                        if coord[0] in range(int(WIDTH * i[0]), int(WIDTH * i[0]) + rect.width) and coord[1] in range(int(HEIGHT * i[1]), int(HEIGHT * i[1]) + rect.height):
                                            back_coord.remove(i)
                                            surface_render()
                                            break
                        else:
                            if player_pos_button.in_rect(*pos):
                                player_pos_choice = not player_pos_choice
                                wall_pos_choice = False
                                back_pos_choice = False
                                enemy_spawn_choice = False
                                if player_pos_choice:
                                    active_sprite, active_half_width, active_half_height = player, player_half_width, player_half_height
                                else:
                                    active_sprite = None
                                ListBox.active_box = None
                                item_choice = False
                                delete = False
                                sc.fill((0, 0, 0))
                                buttons_render()
                            elif wall_pos_button.in_rect(*pos):
                                wall_pos_choice = not wall_pos_choice
                                if wall_pos_choice:
                                    player_pos_choice = False
                                    back_pos_choice = False
                                    enemy_spawn_choice = False
                                    ListBox.active_box = wall_list
                                    wall_list.activated = False
                                    active_sprite = pygame.image.load(getcwd() + sep + "sprites" + sep + "terrain" + sep + "walls" + sep + wall_list.text[wall_list.all_txt.index(wall_list.txt)] + ".png").convert()
                                    if WIDTH != 800:
                                        active_rect = active_sprite.get_rect()
                                        active_sprite = pygame.transform.scale(active_sprite, (int(active_rect.width * WIDTH / 800), int(active_rect.height * HEIGHT / 600 * 1.3)))
                                        del active_rect
                                    active_sprite.set_colorkey((255, 255, 255))
                                    active_half_width, active_half_height = active_sprite.get_rect().width // 2, active_sprite.get_rect().height // 2
                                else:
                                    wall_list.activated = False
                                    ListBox.active_box = None
                                    active_sprite = None
                                    item_choice = False
                                    delete = False
                                sc.fill((0, 0, 0))
                                buttons_render()
                            elif back_pos_button.in_rect(*pos):
                                back_pos_choice = not back_pos_choice
                                if back_pos_choice:
                                    player_pos_choice = False
                                    wall_pos_choice = False
                                    enemy_spawn_choice = False
                                    ListBox.active_box = back_list
                                    back_list.activated = False
                                    active_sprite = pygame.image.load(getcwd() + sep + "sprites" + sep + "terrain" + sep + "background" + sep + back_list.text[back_list.all_txt.index(back_list.txt)] + ".png").convert()
                                    if WIDTH != 800:
                                        active_rect = active_sprite.get_rect()
                                        active_sprite = pygame.transform.scale(active_sprite, (int(active_rect.width * WIDTH / 800), int(active_rect.height * HEIGHT / 600 * 1.3)))
                                        del active_rect
                                    active_sprite.set_colorkey((255, 255, 255))
                                    active_half_width, active_half_height = active_sprite.get_rect().width // 2, active_sprite.get_rect().height // 2
                                else:
                                    back_list.activated = False
                                    ListBox.active_box = False
                                    active_sprite = None
                                    item_choice = False
                                    delete = False
                                sc.fill((0, 0, 0))
                                buttons_render()
                            elif enemy_spawn_button.in_rect(*pos):
                                player_pos_choice = False
                                wall_pos_choice = False
                                back_pos_choice = False
                                enemy_spawn_choice = not enemy_spawn_choice
                                ListBox.active_box = None
                                active_sprite = None
                                item_choice = False
                                delete = False
                                sc.fill((0, 0, 0))
                                buttons_render()
                            elif item_button.in_rect(*pos):
                                player_pos_choice = False
                                wall_pos_choice = False
                                back_pos_choice = False
                                ListBox.active_box = None
                                active_sprite = None
                                enemy_spawn_choice = False
                                item_choice = not item_choice
                                delete = False
                                sc.fill((0, 0, 0))
                                buttons_render()
                            elif delete_button.in_rect(*pos):
                                player_pos_choice = False
                                wall_pos_choice = False
                                back_pos_choice = False
                                ListBox.active_box = None
                                active_sprite = None
                                enemy_spawn_choice = False
                                item_choice = False
                                delete = not delete
                                sc.fill((0, 0, 0))
                                buttons_render()
                            elif markup_button.in_rect(*pos):
                                markup = not markup
                                if markup:
                                    markup_button.change_text("Выключить разметку")
                                else:
                                    markup_button.change_text("Включить разметку")
                                sc.fill((0, 0, 0))
                                buttons_render()
                            elif reset_button.in_rect(*pos):
                                level_x, level_y = 0, 0
                                message_surf.fill((40, 40, 40))
                                message_surf.blit(message_font.render("Координаты уровня сброшены", True, (255, 250, 10)), (int(WIDTH * 0.01), 0))
                            elif save_button.in_rect(*pos):
                                save = True
                                """
                                
                                """
                            elif quit_button.in_rect(*pos):
                                YesNoSurface.active_surf = quit_surf
                            elif ListBox.active_box and ListBox.active_box.in_rect(*pos):
                                if ListBox.active_box.in_rect(*pos) in ListBox.active_box.text:
                                    ListBox.active_box.txt = ListBox.active_box.all_txt[ListBox.active_box.text.index(ListBox.active_box.in_rect(*pos))]
                                    active_sprite = pygame.image.load(getcwd() + sep + "sprites" + sep + "terrain" + sep + ListBox.active_box.description + sep + ListBox.active_box.text[ListBox.active_box.all_txt.index(ListBox.active_box.txt)] + ".png").convert()
                                    if WIDTH != 800:
                                        active_rect = active_sprite.get_rect()
                                        active_sprite = pygame.transform.scale(active_sprite, (int(active_rect.width * WIDTH / 800), int(active_rect.height * HEIGHT / 600 * 1.3)))
                                        del active_rect
                                    active_sprite.set_colorkey((255, 255, 255))
                                    active_half_width, active_half_height = active_sprite.get_rect().width // 2, active_sprite.get_rect().height // 2
                                    ListBox.active_box.activated = False
                                else:
                                    ListBox.active_box.activated = True
                                sc.fill((0, 0, 0))
                                buttons_render()

                elif i.type == pygame.MOUSEWHEEL:
                    pos = pygame.mouse.get_pos()
                    if pos[0] in range(0, WIDTH - WIDTH // 4) and pos[1] in range(HEIGHT // 6, HEIGHT):
                        scaled += i.y / 10
                        if scaled < 0.1:
                            scaled = 0.1
                        elif scaled > 1:
                            scaled = 1
            level_surf.fill((0, 0, 0))
            level_surf.blit(back_surf, (0, 0))
            level_surf.blit(sprite_surf, (0, 0))
            if item_spawn[0] and item_spawn[1]:
                pygame.draw.rect(level_surf, (255, 0, 0), (item_spawn[0] - WIDTH // 40, item_spawn[1] - HEIGHT // 40, WIDTH // 20, HEIGHT // 20), 3)
            if type(player_pos[0]) != type(None):
                level_surf.blit(player, (player_pos[0] - player_half_width, player_pos[1] - player_half_height))
            if active_sprite and pos[0] in range(0, WIDTH - WIDTH // 4) and pos[1] in range(HEIGHT // 6 - int(HEIGHT * 0.05), HEIGHT - int(HEIGHT * 0.05)):
                level_surf.blit(active_sprite, (int((pos[0] - level_x) / scaled) - active_half_width, int((pos[1] - level_y - HEIGHT // 6 + int(HEIGHT * 0.05)) / scaled) - active_half_height))
            if markup:
                for i in range(0, WIDTH, WIDTH // 10):
                    pygame.draw.line(level_surf, (15, 200, 20), (i, 0), (i, HEIGHT), 3)
                    level_surf.blit(level_txt.render(str(i), True, (50, 250, 100)), (i, 0))
                for i in range(0, HEIGHT, HEIGHT // 10):
                    pygame.draw.line(level_surf, (15, 200, 20), (0, i), (WIDTH, i), 3)
                    level_surf.blit(level_txt.render(str(i), True, (50, 250, 100)), (0, i))
            key = pygame.key.get_pressed()
            if key[pygame.K_UP]:
                level_y += 2
                if key[pygame.K_LSHIFT]:
                    level_y += 3
            elif key[pygame.K_DOWN]:
                level_y -= 2
                if key[pygame.K_LSHIFT]:
                    level_y -= 3
            if key[pygame.K_RIGHT]:
                level_x -= 2
                if key[pygame.K_LSHIFT]:
                    level_x -= 3
            elif key[pygame.K_LEFT]:
                level_x += 2
                if key[pygame.K_LSHIFT]:
                    level_x += 3
            pos = pygame.mouse.get_pos()
            if delete:
                if pos[0] in range(0, WIDTH - WIDTH // 4) and pos[1] in range(HEIGHT // 6 - int(HEIGHT * 0.05), HEIGHT - int(HEIGHT * 0.05)):
                        pygame.draw.line(level_surf, (255, 0, 0), (0, int((pos[1] - (HEIGHT // 6 - int(HEIGHT * 0.05)) - level_y) / scaled)), (WIDTH, int((pos[1] - (HEIGHT // 6 - int(HEIGHT * 0.05)) - level_y) / scaled)))
                        pygame.draw.line(level_surf, (255, 0, 0), (int((pos[0] - level_x) / scaled), 0), (int((pos[0] - level_x) / scaled), HEIGHT))
            if player_pos_choice or wall_pos_choice or back_pos_choice or enemy_spawn_choice or item_choice:
                if pos[0] in range(0, WIDTH - WIDTH // 4) and pos[1] in range(HEIGHT // 6 - int(HEIGHT * 0.05), HEIGHT - int(HEIGHT * 0.05)):
                    pygame.draw.line(level_surf, (255, 255, 0), (0, int((pos[1] - (HEIGHT // 6 - int(HEIGHT * 0.05)) - level_y) / scaled)), (WIDTH, int((pos[1] - (HEIGHT // 6 - int(HEIGHT * 0.05)) - level_y) / scaled)))
                    pygame.draw.line(level_surf, (255, 255, 0), (int((pos[0] - level_x) / scaled), 0), (int((pos[0] - level_x) / scaled), HEIGHT))
                if enemy_spawn_choice:
                    pygame.draw.rect(level_surf, (255, 0, 0), (WIDTH // 20, HEIGHT // 10, WIDTH - WIDTH // 20 * 2, HEIGHT - HEIGHT // 10 * 2), 3)
                coord_surf.fill((40, 40, 40))
                coord_surf.blit(message_font.render("X: " + str(int((pos[0] - level_x) / scaled)) + "  Y: " + str(int((pos[1] - level_y - HEIGHT // 6 + int(HEIGHT * 0.05)) / scaled)), True, (255, 250, 10)), (int(WIDTH * 0.01), 0))
            for i in buttons:
                if i.in_rect(*pos):
                    pygame.draw.rect(sc, (255, 10, 40), (i.rect.x, i.rect.y, i.rect.width - 1, i.rect.height - 1), 2)
                    break
            else:
                if ListBox.active_box:
                    if ListBox.active_box.in_rect(*pos):
                        if ListBox.active_box.activated:
                            ListBox.active_box.render()
                            pygame.draw.rect(sc, (255, 10, 40), (ListBox.active_box.rect.x, ListBox.active_box.rect.y + ListBox.active_box.rect.height * ListBox.active_box.text.index(ListBox.active_box.in_rect(*pos)), ListBox.active_box.rect.width - 1, ListBox.active_box.rect.height - 1), 2)
                        else:
                            pygame.draw.rect(sc, (255, 10, 40), (ListBox.active_box.x, ListBox.active_box.rect.y, ListBox.active_box.rect.width - 1, ListBox.active_box.rect.height - 1), 2)
                    else:
                        buttons_render()
                else:
                    buttons_render()
            main_surf.fill((30, 30, 30))
            main_surf.blit(pygame.transform.scale(level_surf, (int(WIDTH * scaled), int(HEIGHT * scaled))), (level_x, level_y))
            sc.blit(main_surf, (0, HEIGHT // 6 - WIDTH // 40))
            sc.blit(message_surf, (0, HEIGHT - int(HEIGHT * 0.05)))
            sc.blit(coord_surf, (WIDTH - WIDTH // 4, HEIGHT - int(HEIGHT * 0.05)))
            if ListBox.active_box and ListBox.active_box.activated:
                ListBox.active_box.render()
                if ListBox.active_box.in_rect(*pos):
                    pygame.draw.rect(sc, (255, 10, 40), (ListBox.active_box.rect.x, ListBox.active_box.rect.y + ListBox.active_box.rect.height * ListBox.active_box.text.index(ListBox.active_box.in_rect(*pos)), ListBox.active_box.rect.width - 1, ListBox.active_box.rect.height - 1), 2)
            clock.tick(FPS)
        elif YesNoSurface.active_surf:
            for i in pygame.event.get():
                if i.type == pygame.QUIT:
                    pygame.quit()
                elif i.type == pygame.MOUSEBUTTONDOWN:
                    if num == 2:
                        ListBox.active_box = None
                        YesNoSurface.active_surf = None
                        return 0
                    elif num == 1:
                        YesNoSurface.active_surf = None
            quit_surf.render()
            pos = pygame.mouse.get_pos()
            num = quit_surf.in_rect(*pos)
            if num == 2:
                pygame.draw.rect(sc, (255, 10, 40), (quit_surf.yes_button.x + quit_surf.x, quit_surf.yes_button.y + quit_surf.y, quit_surf.yes_button.rect.width - 1, quit_surf.yes_button.rect.height - 1), 2)
            elif num == 1:
                pygame.draw.rect(sc, (255, 10, 40), (quit_surf.no_button.x + quit_surf.x, quit_surf.no_button.y + quit_surf.y, quit_surf.no_button.rect.width - 1, quit_surf.no_button.rect.height - 1), 2)
            clock.tick(FPS)
        else:
            pos = pygame.mouse.get_pos()
            num = save_surf.in_rect(*pos)
            for i in pygame.event.get():
                if i.type == pygame.QUIT:
                    pygame.quit()
                elif i.type == pygame.KEYDOWN:
                    key = pygame.key.get_pressed()
                    if key[pygame.K_RETURN]:
                        save_arena()
                elif i.type == pygame.MOUSEBUTTONDOWN:
                    if num == 2:
                        save_arena()
                    elif num == 1:
                        save = False
            save_surf.render()
            if num == 1:
                pygame.draw.rect(save_surf.surf, (255, 10, 40), (save_surf.no_button.rect.x, save_surf.no_button.y, save_surf.no_button.rect.width - 1, save_surf.no_button.rect.height - 1), 2)
            elif num == 2:
                pygame.draw.rect(save_surf.surf, (255, 10, 40), (save_surf.yes_button.x, save_surf.yes_button.y, save_surf.yes_button.rect.width - 1, save_surf.yes_button.rect.height - 1), 2)
            save_surf.enter.add_letter(clock.get_fps())
            clock.tick()
        pygame.display.update()
        pygame.display.set_caption(str(int(clock.get_fps())))

