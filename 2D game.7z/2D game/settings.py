import pygame
from pygame.locals import *
from pickle import load

#Настройки
FPS = 60
with open("settings.data", "rb") as f:
    parameters = load(f)
    WIDTH, HEIGHT = parameters["Разрешение"]
    volume = parameters["Общая громкость"]
sc = pygame.display.set_mode((WIDTH, HEIGHT), DOUBLEBUF)
clock = pygame.time.Clock()
