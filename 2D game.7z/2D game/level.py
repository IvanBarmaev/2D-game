import pygame
from player import *
from enemy import *
from wall import *
from item import *
from particles import *
from weapon import *
import game_logic as gl
from button import *
from settings import *
from pickle import load, dump
from os import sep, getcwd
import game_logic as gl
from copy import deepcopy, copy

pygame.font.init()
fps = pygame.font.SysFont("Lucida Console", 50)


class Floor:
    killed = 0
    main_surf = pygame.Surface((WIDTH, HEIGHT))
    back_surf = pygame.Surface((WIDTH, HEIGHT))
    bullet_group = pygame.sprite.Group()
    enemy_bullet_group = pygame.sprite.Group()
    weapons = {"Pistol": Pistol(main_surf, None, "fiveseven-1.wav", 11, 25, "Пистолет", 10)}
    enemy = {"Soldier": Soldier(0, 0, 0, 2, main_surf, None, 100, None, "soldier.png", add=False)}

    def draw_background(self, background):
        Floor.back_surf.fill((0, 0, 0))
        for i in background:
            self.sprite = pygame.image.load(getcwd() + sep + "sprites" + sep + "terrain" + sep + "background" + sep + i[2]).convert()
            self.sprite.set_colorkey((255, 255, 255))
            if WIDTH != 800:
                self.rect = self.sprite.get_rect()
                self.sprite = pygame.transform.scale(self.sprite, (int(self.rect.width * WIDTH / 800), int(self.rect.height * HEIGHT / 600 * 1.3)))
            Floor.back_surf.blit(self.sprite, (int(WIDTH * i[0]), int(HEIGHT * i[1])))
        del self.sprite

    def __init__(self, walls, background, transition_data, enemy, items, player_pos):
        self.wall_group = pygame.sprite.Group()
        self.enemy_group = pygame.sprite.Group()
        self.item_group = pygame.sprite.Group()
        self.particles_group = pygame.sprite.Group()
        self.transition_area = int(WIDTH * transition_data[0]), int(HEIGHT * transition_data[1]), \
            int(WIDTH * transition_data[2]), int(HEIGHT * transition_data[3])
        self.next_floor = transition_data[4]
        self.player_pos = int(WIDTH * player_pos[0]), int(HEIGHT * player_pos[1])
        for i in walls:
            Wall(int(WIDTH * i[0]), int(HEIGHT * i[1]), self.main_surf, self.wall_group, i[2])
        self.background_data = background
        self.draw_background(self.background_data)
        for i in enemy:
            self.temp_enemy = copy(Floor.enemy[i[0]])
            self.temp_enemy.rect.x = int(WIDTH * i[1])
            self.temp_enemy.rect.y = int(HEIGHT * i[2])
            self.temp_enemy.angle = i[3]
            self.temp_enemy.image = pygame.transform.rotate(self.temp_enemy.image, -i[3])
            if i[4]:
                self.temp_enemy.weapon = copy(Floor.weapons[i[4]])
                self.temp_enemy.weapon.group = Floor.enemy_bullet_group
            self.enemy_group.add(self.temp_enemy)
        del self.temp_enemy
        for i in items:
            i.sc = self.main_surf
            self.item_group.add(i)
        self.transition_surf = pygame.Surface((self.transition_area[2], self.transition_area[3]))
        self.transition_surf.fill((20, 180, 10))
        self.transition_surf.set_alpha(20)

    def render(self, player):
        Floor.main_surf.blit(Floor.back_surf, (0, 0))
        self.particles_group.draw(Floor.main_surf)
        self.wall_group.draw(Floor.main_surf)
        self.item_group.draw(Floor.main_surf)
        Floor.bullet_group.draw(Floor.main_surf)
        Floor.enemy_bullet_group.draw(Floor.main_surf)
        self.enemy_group.draw(Floor.main_surf)
        Floor.main_surf.blit(player.image, (player.rect.x, player.rect.y))
        Floor.main_surf.blit(self.transition_surf, (self.transition_area[0], self.transition_area[1]))
        player.draw_HUD()
        sc.blit(Floor.main_surf, (0, 0))

    def update(self, player, key):
        gl.player_wall_collide(player, self.wall_group)
        player.update(key, pygame.mouse.get_pos())
        player.move = {"left": True, "right": True, "up": True, "down": True}
        if player.rect.right >= WIDTH:
            player.rect.right = WIDTH
        elif player.rect.left <= 0:
            player.rect.left = 0
        if player.rect.bottom >= HEIGHT:
            player.rect.bottom = HEIGHT
        elif player.rect.top <= 0:
            player.rect.top = 0
        gl.enemy_wall_collide(self.enemy_group, self.wall_group)
        Enemy.player_pos = player.rect.center
        self.enemy_group.update(player, self.particles_group, self.back_surf, self.wall_group.sprites())
        Floor.bullet_group.update()
        Floor.killed += gl.bullet_collide(Floor.bullet_group, self.enemy_group, self.particles_group)
        hit = pygame.sprite.groupcollide(Floor.bullet_group, self.wall_group, False, False)
        for i in hit:
            i.wall_collide()
        Floor.enemy_bullet_group.update()
        hit = pygame.sprite.groupcollide(Floor.enemy_bullet_group, self.wall_group, False, False)
        for i in hit:
            i.wall_collide()
        hit = pygame.sprite.spritecollide(player, Floor.enemy_bullet_group, True)
        for i in hit:
            i.collide(player)
        self.item_group.update()
        self.particles_group.update(Floor.back_surf)
        gl.particles_collide(self.particles_group, self.wall_group)


class Level:
    end_font = pygame.font.SysFont("Lucida Console", WIDTH // 30)

    def end_render(self):
        if self.end_text:
            self.end_surf = pygame.Surface((WIDTH, HEIGHT))
            if Level.end_font.render(self.end_text, True, (255, 255, 255)).get_rect().width > WIDTH:
                self.cur_width = 0
                self.row = 1
                self.cur_string = ""
                for i in self.end_text.split(" "):
                    if self.cur_width + Level.end_font.render(i, True, (255, 255, 255)).get_rect().width < WIDTH - WIDTH // 3:
                        self.cur_string += i + " "
                        self.cur_width += Level.end_font.render(i, True, (255, 255, 255)).get_rect().width
                    else:
                        self.end_surf.blit(Level.end_font.render(self.cur_string, True, (255, 255, 255)),
                                           (10, self.row * (Level.end_font.render(i, True, (255, 255, 255)).get_rect().height) + 10))
                        self.cur_string = i + " "
                        self.row += 1
                        self.cur_width = 0
                self.end_surf.blit(Level.end_font.render(self.cur_string, True, (255, 255, 255)),
                                           (10, self.row * (Level.end_font.render(i, True, (255, 255, 255)).get_rect().height) + 10))
            else:
                self.end_surf.blit(Level.end_font.render(self.end_text, True, (255, 255, 255)), (10, 10))

    def __init__(self, floors, player, end=""):
        self.game = True
        self.floors = floors
        self.cur_floor = floors[0]
        self.floor_num = 0
        self.player = player
        self.end_text = end
        self.end_render()

    def set_music(self, name):
        self.music = pygame.mixer.Sound(getcwd() + sep + "sound" + sep + "music" + sep + name)
        self.music.set_volume(volume)

    def update(self):
        self.cur_floor.update(self.player, pygame.key.get_pressed())
        self.cur_floor.render(self.player)
        if self.player.rect.center[0] in range(self.cur_floor.transition_area[0],
                                               self.cur_floor.transition_area[0] + self.cur_floor.transition_area[2]) \
                and self.player.rect.center[1] in range(self.cur_floor.transition_area[1],
                                                   self.cur_floor.transition_area[1] + self.cur_floor.transition_area[3]):
            for i in self.cur_floor.enemy_group.sprites():
                i.alarm = False
            self.floor_num = self.floors[self.floor_num].next_floor
            if self.floor_num >= 0:
                self.cur_floor = self.floors[self.floor_num]
                self.player.rect.center = self.cur_floor.player_pos
                self.cur_floor.draw_background(self.cur_floor.background_data)
                Floor.bullet_group.empty()
                Floor.enemy_bullet_group.empty()
            elif self.end_text:
                sc.fill((0, 0, 0))
                sc.blit(self.end_surf, (0, 0))
                pygame.display.flip()
                for i in range(FPS * 10):
                    for j in pygame.event.get():
                        if j.type == pygame.QUIT:
                            pygame.quit()
                        elif j.type == pygame.MOUSEBUTTONUP:
                            self.game = False
                            return 0
                    clock.tick(FPS)
                self.game = False
            else:
                self.game = False


if __name__ == "__main__":
    with open("test_level.data", "rb") as f:
        data = load(f)
    f1 = Floor(data[0][0], data[0][1], data[0][2], data[0][3], data[0][4], data[0][5])
    f2 = Floor(data[1][0], data[1][1], data[1][2], data[1][3], data[1][4], data[1][5])
    player = Player(WIDTH // 4, HEIGHT // 4, 3, Floor.main_surf, [])
    pistol = Pistol(Floor.main_surf, Floor.bullet_group, "fiveseven-1.wav", 15, 30, "Пистолет", 20, 10)
    player.weapon_list.append(pistol)
    player.weapon = pistol
    l = Level([f1, f2], player, "Спасибо за прохождение! Можно этот текст будет нормально переноситься?")
    l.set_music("test.mp3")
    l.music.play()
    while l.game:
        for i in pygame.event.get():
            if i.type == pygame.QUIT:
                pygame.quit()
        key = pygame.mouse.get_pressed()
        if key[0]:
            if pygame.mouse.get_focused():
                player.weapon.shoot(player.rect, pygame.mouse.get_pos())
        player.weapon.step()
        l.update()
        l.cur_floor.render(player)
        text = fps.render(str(int(clock.get_fps())), True, (255, 255, 255))
        sc.blit(text, (20, 20))
        pygame.display.flip()
        clock.tick(FPS)
