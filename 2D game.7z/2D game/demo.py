import pygame
from enemy import *
from player import Player
from button import Button
from math import *
from item import *
from weapon import *
from trigger import *
from wall import *
from settings import *
from button import *
import game_logic as gl
import pickle
from os import sep, getcwd
from particles import *
from random import randint

pygame.font.init()
def demo():
    hud_font = pygame.font.SysFont("Arial", int(WIDTH / 50 + HEIGHT / 50) - 1)
    main_surf = pygame.Surface((WIDTH, HEIGHT))
    back_surf = pygame.Surface((WIDTH, HEIGHT))
    main_surf_coord = [0, 0]
    coord_shift = []
    surf_angle = 0
    surf_angle_limit = 0.3
    player = Player(WIDTH - WIDTH // 10, HEIGHT, 3, main_surf, [])
    enemy_group = pygame.sprite.Group()
    bullet_group = pygame.sprite.Group()
    enemy_bullet_group = pygame.sprite.Group()
    item_group = pygame.sprite.Group()
    trigger_group = pygame.sprite.Group()
    wall_group = pygame.sprite.Group()
    destruct_wall_group = pygame.sprite.Group()
    destruct_wall_group = pygame.sprite.Group()
    particles_group = pygame.sprite.Group()
    """
    Wall(WIDTH // 4, HEIGHT // 4, main_surf, wall_group, "wall1.png").change_size(WIDTH // 3, HEIGHT // 20)
    Wall(WIDTH // 4, HEIGHT // 4 + HEIGHT // 10, main_surf, wall_group, "wall.png")
    for i in range(3):
        Wall(WIDTH // 4 + WIDTH // 4 * i, HEIGHT // 4 + HEIGHT // 10, main_surf, wall_group, "wall.png")
    for i in range(2):
        Wall(WIDTH // 4 + WIDTH // 4 * i + int(100 * WIDTH / 800), HEIGHT // 4 + int(90 * HEIGHT / 600 * 1.6) - 20, main_surf, wall_group, "wall.png")
    """
    Wall(WIDTH // 2, HEIGHT // 4, main_surf, wall_group, "wall1.png").change_size(WIDTH // 3, HEIGHT // 20)
    Wall(WIDTH // 4, HEIGHT // 4, main_surf, wall_group, "wall1.png").change_size(WIDTH // 3, HEIGHT // 20)
    Wall(WIDTH // 2, HEIGHT - HEIGHT // 4, main_surf, wall_group, "wall1.png").change_size(WIDTH // 3, HEIGHT // 20)
    Wall(WIDTH // 4, HEIGHT - HEIGHT // 4, main_surf, wall_group, "wall1.png").change_size(WIDTH // 3, HEIGHT // 20)
    for i in range(3):
        Wall(WIDTH // 4 + WIDTH // 4 * i - 50, HEIGHT // 4 + HEIGHT // 10 + 50, main_surf, wall_group, "wall.png")
    for i in range(2):
        Wall(WIDTH // 4 + WIDTH // 4 * i + int(100 * WIDTH / 800) - 50, HEIGHT // 4 + int(90 * HEIGHT / 600 * 1.6) + 30, main_surf, wall_group, "wall.png")
    #Wall(WIDTH // 4, HEIGHT // 4, main_surf, wall_group, "wall2.png").change_size(WIDTH // 30, HEIGHT // 2)
    #Wall(WIDTH // 2, HEIGHT // 4, main_surf, wall_group, "wall2.png").change_size(WIDTH // 30, HEIGHT // 2)
    Heal(int(WIDTH / 100 * 36), HEIGHT // 10, main_surf, item_group, "heal.png", "djump.wav", 50)
    player.weapon_list.append(Pistol(main_surf, bullet_group, "fiveseven-1.wav", 15, 30, "Пистолет", 20))
    player.weapon = player.weapon_list[0]
    player.hp = 99999999
    Soldier(WIDTH - WIDTH // 6 + 100, HEIGHT // 2, 0, 2, main_surf, enemy_group, 100, Pistol(main_surf, enemy_bullet_group, "fiveseven-1.wav", 11, 25, "Пистолет", 10), "soldier" + sep + "soldier.png").new_point((WIDTH - WIDTH // 6 + 80, HEIGHT // 2))
    with open("settings.data", "rb") as f:
        param = pickle.load(f)
    while True:
        Enemy.player_pos = player.rect.center
        for i in pygame.event.get():
            if i.type == pygame.QUIT:
                pygame.quit()

        key = pygame.mouse.get_pressed()
        pos = pygame.mouse.get_pos()
        if key[0]:
            if pygame.mouse.get_focused():
                if player.weapon.type == "long":
                    if player.weapon.bool_delay and param["Отдача"] > 0:
                        gl.surf_shift(coord_shift, player.weapon.shift)
                    player.weapon.shoot(player.rect, pos)
        player.weapon.step()
        
        key = pygame.key.get_pressed()
        if key[pygame.K_ESCAPE]:
            buttons = [Button(sc, 50, 50, "Продолжить", WIDTH // 50, None, "Продолжить игру"), Button(sc, 50, 50 + 5 * HEIGHT // 50, "Выйти", WIDTH // 50, None, "Завершить игру и выйти в меню")]
            pause = True
            while pause:
                pos = pygame.mouse.get_pos()
                for i in pygame.event.get():
                    if i.type == pygame.QUIT:
                        pygame.quit()
                    if i.type == pygame.MOUSEBUTTONUP:
                        for j in buttons:
                            if j.in_rect(*pos):
                                if buttons.index(j):
                                    return 0
                                else:
                                    pause = False
                for i in buttons:
                    if i.in_rect(*pos):
                        pygame.draw.rect(sc, (255, 20, 40), (i.rect.x, i.rect.y, i.rect.width - 1, i.rect.height - 1), 2)
                    else:
                        i.render()
                pygame.display.flip()
                clock.tick(FPS)
                pygame.display.set_caption(str(int(clock.get_fps())))
        if player.hp <= 0:
            return 0
        gl.enemy_wall_collide(enemy_group, wall_group)
        #Обновления
        main_surf.blit(back_surf, (0, 0))
        bullet_group.update()
        gl.player_wall_collide(player, wall_group)
        particles_group.update(back_surf)
        item_group.update(player)
        enemy_group.update(player, particles_group, back_surf, wall_group)
        enemy_bullet_group.update()
        gl.enemy_wall_collide(enemy_group, wall_group)
        gl.particles_collide(particles_group, wall_group)

        gl.bullet_collide(bullet_group, enemy_group, particles_group)
        
        #Проверка на столкновение пуль и стен
        hit = pygame.sprite.groupcollide(bullet_group, wall_group, False, False)
        for i in hit:
            i.wall_collide()

        #Проверка на столкновение вражеских пулб и стен
        for i in pygame.sprite.groupcollide(enemy_bullet_group, wall_group, False, False):
            i.wall_collide()

        hit_bullet_list = pygame.sprite.spritecollide(player, enemy_bullet_group, True)
        for i in hit_bullet_list:
            i.collide(player)

        if not enemy_group.sprites():
            Soldier(WIDTH - WIDTH // 6, HEIGHT // 2, 180, 2, main_surf, enemy_group, 100, Pistol(main_surf, enemy_bullet_group, "fiveseven-1.wav", 11, 25, "Пистолет", 10), "soldier" + sep + "soldier.png").new_point((WIDTH - WIDTH // 6 - 20, HEIGHT // 2))
        #Отрисовка
        particles_group.draw(main_surf)
        enemy_bullet_group.draw(main_surf)
        bullet_group.draw(main_surf)
        wall_group.draw(main_surf)
        item_group.draw(main_surf)
        enemy_group.draw(main_surf)
        main_surf.blit(player.image, player.rect)
        text = hud_font.render("Здоровье: " + str(player.hp) + "   Оружие: " + str(player.weapon.name), True, (10, 5, 255))
        pos = pygame.mouse.get_pos()
        player.update(key, pos)
        player.move = {"left":True, "right":True, "up":True, "down":True}
        if player.rect.left < 0:
            player.rect.left = 0
        elif player.rect.right > WIDTH:
            player.rect.right = WIDTH
        if player.rect.top < 0:
            player.rect.top = 0
        elif player.rect.bottom > HEIGHT:
            player.rect.bottom = HEIGHT
        player.draw_HUD()
        if param["Покачивание"] > 0:
            surf_angle, surf_angle_limit = gl.surf_rotate(surf_angle, surf_angle_limit, key)
        if coord_shift:
            sc.blit(pygame.transform.rotate(main_surf, surf_angle), (main_surf_coord[0] + coord_shift[0][0], main_surf_coord[1] + coord_shift[0][1]))
            coord_shift.pop(0)
        else:
            sc.blit(pygame.transform.rotate(main_surf, surf_angle), main_surf_coord)
        sc.blit(text, (10, HEIGHT - 50))
        if player.armor:
            text = hud_font.render("Броня: " + str(player.armor), True, (10, 5, 255))
            sc.blit(text, (10, HEIGHT - 100))
        trigger_group.update(player.rect) #Для отображения сообщений
        pygame.display.set_caption(str(int(clock.get_fps())))
        pygame.display.update()
        clock.tick(FPS)
