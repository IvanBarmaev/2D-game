import pygame
from enemy import *
from player import Player
from bullet import Bullet
from button import Button
from math import *
from random import choice, randint
from item import *
from weapon import *
from trigger import *
from wall import *
from settings import *
#import some_tools
from button import *
import game_logic as gl
from enter import *
import pickle
from os import sep, getcwd
from particles import *

pygame.font.init()

#Шрифты
main_font = pygame.font.Font(None, 50)
hud_font = pygame.font.Font(None, int(WIDTH / 50 + HEIGHT / 50) - 1)

#Основной цикл
#wall_list - список с координатами и спрайтами стен
#spawn_coord - координаты для NPC
#player_coord - координаты игрока
def arena(wall_list, back_list, spawn_coord, player_coord):
    main_surf = pygame.Surface((WIDTH, HEIGHT))
    back_surf = pygame.Surface((WIDTH, HEIGHT))
    #Фон
    for i in back_list:
        sprite = pygame.image.load(getcwd() + sep + "sprites" + sep + "terrain" + sep + "background" + sep + i[2]).convert()
        sprite.set_colorkey((255, 255, 255))
        if WIDTH != 800:
            rect = sprite.get_rect()
            sprite = pygame.transform.scale(sprite, (int(rect.width * (WIDTH / 800)), int(rect.height * (HEIGHT / 600 * 1.3))))
        back_surf.blit(sprite, (int(i[0] * WIDTH), (i[1] * HEIGHT)))
    main_surf_coord = [0, 0]
    coord_shift = []
    surf_angle = 0
    surf_angle_limit = 0.3
    player = Player(eval(player_coord)[0], eval(player_coord)[1], 3, main_surf, [])
    bullet_group = pygame.sprite.Group()
    enemy_bullet_group = pygame.sprite.Group()
    enemy_group = pygame.sprite.Group()
    item_group = pygame.sprite.Group()
    trigger_group = pygame.sprite.Group()
    wall_group = pygame.sprite.Group()
    particles_group = pygame.sprite.Group()
    walls = wall_list.split("N")
    walls.remove("")
    for i in walls:
        args = eval(i)
        Wall(args[0], args[1], main_surf, wall_group, args[2])
    trigger_group.add(Item_Trigger(500, 400, 50, 50, main_surf, item_group, "heal.png", "djump.wav", 50, 100, 100))
    trigger_group.add(Item_Trigger(500, 400, 50, 50, main_surf, item_group, "bullets_box.png", "p90_boltpull.wav", 50, 150, 100))
    #trigger_group.add(Enemy_Trigger(200, 400, 200, 200, sc, enemy_group, "", 0, 50, 10, "y"))
    pistol = Pistol(main_surf, bullet_group, "fiveseven-1.wav", 15, 30, "Пистолет", 20, 20)
    player.weapon_list.append(pistol)
    player.weapon = pistol
    #Список с кортежами для создания врагов
    enemy_coord = spawn_coord.split("N")
    parameters = []
    for i in enemy_coord:
        parameters.append(eval(i))
    score = 0
    time = 0.0
    spawn_item = True
    spawn_time = 25
    enemy_spawn = True
    weapon_spawn = [("shotgun.png", "m3_pump.wav", Shotgun(main_surf, bullet_group, "m3-1.wav", 15, 80, "Дробовик", 10), 40), \
                    ("machine gun.png", "m3_pump.wav", Pistol(main_surf, bullet_group, "fiveseven-1.wav", 15, 8, "Пулемет", 50, 110), 80),\
                    ("rocketlauncher.png", "m3_pump.wav", RocketLauncher(main_surf, bullet_group, "rocketlauncher.wav", 10, 45, "Ракетница", 50), 120)]
    #player.hp = 9999999
    with open("settings.data", "rb") as f:
        param = pickle.load(f)
    pygame.event.set_allowed([pygame.QUIT])
    while True:
        for i in pygame.event.get():
            if i.type == pygame.QUIT:
                pygame.quit()
        main_surf.fill((0, 0, 0))
        key = pygame.key.get_pressed()
        if key[pygame.K_ESCAPE]:
            buttons = [Button(sc, 50, 50, "Продолжить", WIDTH // 50, None, "Продолжить игру"), Button(sc, 50, 50 + 5 * HEIGHT // 50, "Выйти", WIDTH // 50, None, "Завершить игру и выйти в меню")]
            pause = True
            while pause:
                pos = pygame.mouse.get_pos()
                for i in pygame.event.get():
                    if i.type == pygame.QUIT:
                        pygame.quit()
                    if i.type == pygame.MOUSEBUTTONUP:
                        for j in buttons:
                            if j.in_rect(*pos):
                                if buttons.index(j):
                                    wall_group.empty()
                                    enemy_bullet_group.empty()
                                    bullet_group.empty()
                                    enemy_group.empty()
                                    item_group.empty()
                                    trigger_group.empty()
                                    particles_group.empty()
                                    Wall.index = 0
                                    return 0
                                else:
                                    pause = False
                for i in buttons:
                    if i.in_rect(*pos):
                        pygame.draw.rect(sc, (255, 20, 40), (i.rect.x, i.rect.y, i.rect.width - 1, i.rect.height - 1), 2)
                    else:
                        i.render()
                pygame.display.flip()
                clock.tick(FPS)
                pygame.display.set_caption(str(int(clock.get_fps())))
                    
        pos = pygame.mouse.get_pos()
        gl.player_wall_collide(player, wall_group)
        player.update(key, pos)
        if param["Покачивание"]:
            surf_angle, surf_angle_limit = gl.surf_rotate(surf_angle, surf_angle_limit, key)
        player.move = {"left":True, "right":True, "up":True, "down":True}
        if player.rect.right >= WIDTH:
            player.rect.right = WIDTH
        elif player.rect.left <= 0:
            player.rect.left = 0
        if player.rect.bottom >= HEIGHT:
            player.rect.bottom = HEIGHT
        elif player.rect.top <= 0:
            player.rect.top = 0

        main_surf.blit(back_surf, (0, 0))  #background отрисовывается здесь, потому что на следующих строках отрисовывается поле зрения врагов и их здоровье
        key = pygame.mouse.get_pressed()
        if key[0]:
            if pygame.mouse.get_focused():
                if player.weapon.bool_delay and param["Отдача"]:
                    gl.surf_shift(coord_shift, player.weapon.shift)
                player.weapon.shoot(player.rect, pos)
        player.weapon.step()
        gl.enemy_wall_collide(enemy_group, wall_group)

        #Обновления
        trigger_group.update(player.rect)
        item_group.update(player)
        Enemy.player_pos = (player.rect.center)
        enemy_group.update(player, particles_group, back_surf, wall_group.sprites())
        bullet_group.update()
        enemy_bullet_group.update()
        particles_group.update(back_surf)

        #Отрисовка
        particles_group.draw(main_surf)
        wall_group.draw(main_surf)
        enemy_group.draw(main_surf)
        bullet_group.draw(main_surf)
        enemy_bullet_group.draw(main_surf)
        enemy_group.draw(main_surf)
        item_group.draw(main_surf)
        player.draw_HUD()  #Отрисовка HUD'а

        #Столкновение частиц и стен
        gl.particles_collide(particles_group, wall_group)
        #Проверка на столкновение пуль и стен
        hit = pygame.sprite.groupcollide(bullet_group, wall_group, False, False)
        for i in hit:
            i.wall_collide()

        #Проверка на столкновение вражеских пулб и стен
        for i in pygame.sprite.groupcollide(enemy_bullet_group, wall_group, False, False):
            i.wall_collide()
        
        #Проверка на столкновение врагов и пуль
        k = gl.bullet_collide(bullet_group, enemy_group, particles_group)
        score += k
        for i in range(k):
            rand_num = randint(0, 1)
            enemy_parameters = choice(parameters)
            if rand_num:
                Soldier(enemy_parameters[0], enemy_parameters[1], enemy_parameters[2], 2, main_surf, enemy_group, 100, Pistol(main_surf, enemy_bullet_group, "fiveseven-1.wav", 11, 25, "Пистолет", 10), "soldier" + sep + "soldier.png").new_point(enemy_parameters[3])
            else:
                Dog(enemy_parameters[0], enemy_parameters[1], enemy_parameters[2], 4, main_surf, enemy_group, 50, "dog.png").new_point(enemy_parameters[3])

        #Проверка на столкновение вражеских пуль и игрока
        hit_bullet_list = pygame.sprite.spritecollide(player, enemy_bullet_group, True)
        for i in hit_bullet_list:
            i.collide(player)
        
        #Отрисовка игрока
        main_surf.blit(player.image, player.rect)

        #
        t = str(int(time)) + str(time - int(time))[1:4]   #Форматирование времени
        text = hud_font.render("Здоровье: " + str(player.hp) + "        Патроны: " + str(player.weapon.bullets) + "        Оружие: " + player.weapon.name\
               + "        Очки: " + str(score) + "        Время: {0}".format(t), True, (10, 5, 255))
        
        if player.hp <= 0:
            n = 0
            name = Enter(main_surf, WIDTH // 6, WIDTH // 2 - WIDTH // 12, HEIGHT // 2 + HEIGHT // 10)
            while True:
                for j in pygame.event.get():
                    if j.type == pygame.QUIT:
                        pygame.quit()
                key = pygame.key.get_pressed()
                if key[pygame.K_RETURN]:
                    with open("leaderboard.data", "rb") as f:
                        leaders = pickle.load(f)
                    if len(leaders) == 0:
                        leaders.append([1, name.text, t, score, float(str(score/float(t))[1:4])])
                    else:
                        st = float(str(score/float(t))[1:4])
                        position = len(leaders)
                        for i in leaders[::-1]:
                            if st > i[4]:
                                position -= 1
                            else:
                                if position == 10:
                                    break
                                else:
                                    leaders.insert(position, [position + 1, name.text, t, score, st])
                                    for i in leaders[position+1:len(leaders)]:
                                        i[0] += 1
                                    break
                        else:
                            leaders.insert(position, [position + 1, name.text, t, score, st])
                            for i in leaders[1:len(leaders)]:
                                i[0] += 1
                        if len(leaders) > 10:
                            leaders.pop(10)
                    with open("leaderboard.data", "wb") as f:
                        pickle.dump(leaders, f)
                    break
                elif key[pygame.K_ESCAPE]:
                    return 0
                text = main_font.render("Вы проиграли", True, (n, 0, 0))
                main_surf.blit(text, (WIDTH // 3, HEIGHT // 2))
                if n < 255:
                    n += 1
                name.add_letter(clock.get_fps())
                name.render()
                sc.blit(main_surf, (0, 0))
                pygame.display.flip()
                pygame.display.set_caption(str(int(clock.get_fps())))
                clock.tick()
            break
        #Создание объектов
        time += 1 / FPS
        if int(time) % spawn_time == 0 and int(time) > 1 and spawn_item:
            choice([Heal(WIDTH // 2, HEIGHT // 2, main_surf, item_group, "heal.png", "djump.wav", 50), \
                 Bullets(WIDTH // 2 + 50, HEIGHT // 2, main_surf, item_group, "bullets_box.png", "p90_boltpull.wav", 100)])
            spawn_item = False
            if int(time) % 50 == 0:
                Armor(WIDTH // 2, HEIGHT // 2 + 50, main_surf, item_group, "armor.png", "armor.wav", 50)
        elif int(time) % spawn_time != 0:
            spawn_item = True
        if int(time) == 5 and enemy_spawn:
            rand_num = randint(0, 1)
            enemy_parameters = choice(parameters)
            if rand_num:
                Soldier(enemy_parameters[0], enemy_parameters[1], enemy_parameters[2], 2, main_surf, enemy_group, 100, Pistol(main_surf, enemy_bullet_group, "fiveseven-1.wav", 11, 25, "Пистолет", 10), "soldier" + sep + "soldier.png").new_point(enemy_parameters[3])
            else:
                Dog(enemy_parameters[0], enemy_parameters[1], enemy_parameters[2], 4, main_surf, enemy_group, 50, "dog.png").new_point(enemy_parameters[3])
            enemy_spawn = False
        #Создание оружия
        if len(weapon_spawn) and int(time) == weapon_spawn[0][3]:
            Weapon_Item(WIDTH // 2, HEIGHT // 2, main_surf, item_group, weapon_spawn[0][0], weapon_spawn[0][1], weapon_spawn[0][2])
            weapon_spawn.pop(0)
            rand_num = randint(0, 1)
            enemy_parameters = choice(parameters)
            if rand_num:
                Soldier(enemy_parameters[0], enemy_parameters[1], enemy_parameters[2], 2, main_surf, enemy_group, 100, Pistol(main_surf, enemy_bullet_group, "fiveseven-1.wav", 11, 25, "Пистолет", 10), "soldier" + sep + "soldier.png").new_point(enemy_parameters[3])
            else:
                Dog(enemy_parameters[0], enemy_parameters[1], enemy_parameters[2], 4, main_surf, enemy_group, 50, "dog.png").new_point(enemy_parameters[3])
                
        if coord_shift:
            sc.blit(pygame.transform.rotate(main_surf, surf_angle), (main_surf_coord[0] + coord_shift[0][0], main_surf_coord[1] + coord_shift[0][1]))
            coord_shift.pop(0)
        else:
            sc.blit(pygame.transform.rotate(main_surf, surf_angle), main_surf_coord)
        sc.blit(text, (0, HEIGHT - 35))

        if player.armor:
            text = hud_font.render("Броня: " + str(player.armor), True, (15, 10, 250))
            sc.blit(text, (0, HEIGHT - 60))
        sc.blit(hud_font.render(str(int(clock.get_fps())), True, (255, 255, 255)), (10, 10))
        pygame.display.flip()
        pygame.display.set_caption(str(int(clock.get_fps())))
        clock.tick(FPS)
