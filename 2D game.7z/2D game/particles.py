import pygame
from settings import WIDTH, HEIGHT
from os import getcwd, sep
from math import sin, cos, radians
from random import choice
from pickle import load


class Particles(pygame.sprite.Sprite):
    def __init__(self, sc, group, sprite, x, y, speed, angle):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load(getcwd() + sep + "sprites" + sep + "particles" + sep + sprite)
        self.rect = self.image.get_rect(center=(x, y))
        if WIDTH != 800 and HEIGHT != 600:
            self.image = pygame.transform.scale(self.image, (int(self.rect.width * WIDTH / 800), int(self.rect.height * HEIGHT / 600 * 1.3)))
            self.rect = self.image.get_rect(center=(x, y))
        self.image.set_colorkey((255, 255, 255))
        self.speedx = -cos(radians(angle)) * speed
        self.speedy = -sin(radians(angle)) * speed
        self.distance = 0
        self.delay = 0
        self.speed = speed
        with open("settings.data", "rb") as f:
            self.save_sprite = load(f)["Сохранять спрайты"]
        self.add(group)

    def update(self, surface):
        self.rect.x += int(self.speedx * WIDTH / 800)
        self.rect.y += int(self.speedy * WIDTH / 800)
        self.distance += self.speed
        if self.distance > int(50 * WIDTH / 800) and self.delay == 0:
            self.sprite = choice(["blood_puddle0.png", "blood_puddle1.png"])
            self.image = pygame.image.load(getcwd() + sep + "sprites" + sep + "particles" + sep + self.sprite)
            self.rect = self.image.get_rect(center=(self.rect.centerx, self.rect.centery))
            if WIDTH != 800 and HEIGHT != 600:
                self.image = pygame.transform.scale(self.image, (int(self.rect.width * WIDTH / 800), int(self.rect.height * HEIGHT / 600 * 1.3)))
            self.image.set_colorkey((255, 255, 255))
            self.rect = self.image.get_rect(center=(self.rect.centerx, self.rect.centery))
            self.speedx, self.speedy = 0, 0
            self.delay += 1
            self.width, self.height = self.rect.width, self.rect.height
            if self.save_sprite > 0:
                surface.blit(self.image, (self.rect.x, self.rect.y))
                self.kill()
        if self.delay != 0:
            self.delay += 1
            if self.delay >= 100:
                self.image = pygame.image.load(getcwd() + sep + "sprites" + sep + "particles" + sep + self.sprite).convert()
                self.image = pygame.transform.scale(self.image, (self.width, self.height))
                self.image.set_colorkey((255, 255, 255))
                self.rect = self.image.get_rect(center=self.rect.center)
                self.width -= 1
                self.height -= 1
                if self.width < 2:
                    self.kill()
                    
    def collide(self, obj):
        self.distance = int(51 * WIDTH / 800)


class PhysObj(Particles):
    def __init__(self, sc, group, sprite, x, y, speed, angle, rotate_speed):
        Particles.__init__(self, sc, group, sprite, x, y, speed, angle)
        self.rotate_speed = rotate_speed
        self.sprite = pygame.image.load(getcwd() + sep + "sprites" + sep + "particles" + sep + sprite).convert()
        self.rect = self.image.get_rect(center=(x, y))
        if WIDTH != 800 and HEIGHT != 600:
            self.sprite = pygame.transform.scale(self.sprite, (int(self.rect.width * WIDTH / 800 / 1.8), int(self.rect.height * HEIGHT / 600)))
            self.rect = self.image.get_rect(center=(x, y))
        self.angle = angle

    def update(self, surface):
        self.image = self.sprite
        self.image = pygame.transform.rotate(self.image, -self.angle)
        self.image.set_colorkey((255, 255, 255))
        self.angle += self.rotate_speed
        self.rect.x += self.speedx
        self.rect.y += self.speedy
        self.speedx = self.speedx + 0.2 if self.speedx < 0 else self.speedx - 0.2
        self.speedy = self.speedy + 0.2 if self.speedy < 0 else self.speedy - 0.2
        self.rotate_speed -= 0.5
        self.rotate_speed = 0 if self.rotate_speed < 0 else self.rotate_speed
        if self.speedx >= -1 and self.speedx <= 1:
            self.speedx = 0
        if self.speedy >= -1 and self.speedy <= 1:
            self.speedy = 0
        if self.speedx == 0 and self.speedy == 0:
            if self.save_sprite > 0:
                surface.blit(self.image, (self.rect.x, self.rect.y))
                self.kill()
            self.delay += 1
            if self.delay > 200:
                self.kill()

    def collide(self, obj):
        if self.rect.right in range(obj.rect.left, obj.rect.left + 10) or self.rect.left in range(obj.rect.right-10, obj.rect.right):
            self.speedx *= -0.7
        elif self.rect.top in range(obj.rect.bottom - 10, obj.rect.bottom) or self.rect.bottom in range(obj.rect.top, obj.rect.top + 10):
            self.speedy *= -0.7
