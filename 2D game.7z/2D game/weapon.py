import pygame
from bullet import *
from math import sqrt, degrees, acos
from random import randint
from os import getcwd, sep
from settings import volume

pygame.mixer.init()


class Weapon:
    def __init__(self, sc, group, sound, speed, delay_max, name, bullet_damage):
        self.sc = sc
        self.group = group
        self.speed = speed
        self.delay_max = delay_max
        self.delay = 0
        self.bool_delay = True
        self.sound_name = sound
        self.sound = pygame.mixer.Sound(getcwd() + sep + "sound" + sep + "weapon_sound" + sep + sound)
        self.name = name
        self.bullet_damage = bullet_damage
        self.shift = bullet_damage // 10
        self.sound.set_volume(volume * 0.2)
        self.type = "long"

    def step(self):
        if not self.bool_delay:
            self.delay += 1
            if self.delay >= self.delay_max:
                self.delay = 0
                self.bool_delay = True


class Pistol(Weapon):
    bullets = 500

    def __init__(self, sc, group, sound, speed, delay_max, name, bullet_damage, spread=0):
        Weapon.__init__(self, sc, group, sound, speed, delay_max, name, bullet_damage)
        self.spread = spread  #Переменная отвечающая за разброс пуль

    def shoot(self, obj_rect, pos):
        if self.bullets > 0 and self.bool_delay:
            self.gip = sqrt((obj_rect.centerx - pos[0]) ** 2 + (obj_rect.centery - pos[1]) ** 2)
            speedy = -((obj_rect.centery - pos[1]) / self.gip) * self.speed + randint(-self.spread, self.spread) / 100
            speedx = -((obj_rect.centerx - pos[0]) / self.gip) * self.speed + randint(-self.spread, self.spread) / 100
            Bullet(obj_rect.centerx, obj_rect.centery, speedx, speedy, self.bullet_damage, self.sc, self.group, "bullet.png")
            self.bullets -= 1
            self.sound.play()
            self.bool_delay = False

    def __copy__(self):
        return Pistol(self.sc, None, self.sound_name, self.speed, self.delay_max, self.name, self.bullet_damage, self.spread)

class Shotgun(Weapon):
    bullets = 500

    def __init__(self, sc, group, sound, speed, delay_max, name, bullet_damage):
        Weapon.__init__(self, sc, group, sound, speed, delay_max, name, bullet_damage)
        self.shift *= 10
        
    def shoot(self, obj_rect, pos):
        if self.bullets > 0 and self.bool_delay:
            gip = sqrt((obj_rect.centerx - pos[0]) ** 2 + (obj_rect.centery - pos[1]) ** 2)
            speedy = -((obj_rect.centery - pos[1]) / gip) * self.speed
            speedx = -((obj_rect.centerx - pos[0]) / gip) * self.speed
            for i in range(10):
                Bullet(obj_rect.centerx, obj_rect.centery, speedx + randint(-1, 1), speedy + randint(-1, 1), self.bullet_damage, self.sc, self.group, "bullet.png")
            self.bullets -= 1
            self.sound.play()
            self.bool_delay = False

    def __copy__(self):
        return Shotgun(self.sc, None, self.sound_name, self.speed, self.delay_max, self.name, self.bullet_damage)


class RocketLauncher(Weapon):
    bullets = 100

    def __init__(self, sc, group, sound, speed, delay_max, name, bullet_damage=0):
        Weapon.__init__(self, sc, group, sound, speed, delay_max, name, bullet_damage=0)
        self.shift = 1
        self.sound.set_volume(0.2)

    def shoot(self, obj_rect, pos):
        if self.bullets > 0 and self.bool_delay:
            self.gip = sqrt((obj_rect.centerx - pos[0]) ** 2 + (obj_rect.centery - pos[1]) ** 2)
            self.angle = degrees(acos((obj_rect.centerx - pos[0]) / self.gip))
            if pos[1] > obj_rect.centery:
                self.angle = 360 - self.angle
            speedy = -(obj_rect.centery - pos[1]) / self.gip * self.speed
            speedx = -(obj_rect.centerx - pos[0]) / self.gip * self.speed
            Rocket(obj_rect.centerx, obj_rect.centery, 6, speedx, speedy, self.sc, self.group, 0, "rocket.png", self.angle)
            self.bullets -= 1
            self.sound.play()
            self.bool_delay = False

    def __copy__(self):
        return RocketLauncher(self.sc, None, self.sound_name, self.speed, self.delay_max, self.name)

class MeleeWeapon:
    def __init__(self, delay, name, damage, dist, sound):
        self.delay_max = delay
        self.delay = 0
        self.bool_delay = True
        self.name = name
        self.damage = damage
        self.dist = dist
        self.type = "melee"
        self.bullets = 0
        self.sound = pygame.mixer.Sound(getcwd() + sep + "sound" + sep + "weapon_sound" + sep + sound)
        self.sound.set_volume(volume)

    def step(self):
        if not self.bool_delay:
            self.delay += 1
            if self.delay >= self.delay_max:
                self.delay = 0
                self.bool_delay = True
    
    def attack(self, pos, sprites):
        self.kill = 0
        if self.bool_delay:
            self.sound.play()
            for i in sprites:
                distance = sqrt((pos[0] - i.rect.centerx) ** 2 + (pos[1] - i.rect.centery) ** 2)
                if distance <= self.dist:
                    i.hit(self.damage)
                    if i.hp <= 0:
                        self.kill += 1
            self.bool_delay = False 
        return self.kill
