from pickle import load
with open("Стандартная арена.data", "rb") as f:

    print(load(f))
