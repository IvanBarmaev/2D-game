import pickle

l = {"Покачивание":1, "Отдача":1, "Разрешение":(1280, 720), "Сохранять спрайты":1, "Общая громкость":0.5}
with open("settings.data", "wb") as f:
    pickle.dump(l, f)
