import pygame
from settings import WIDTH, HEIGHT
from math import *
from os import getcwd, sep


pygame.font.init()
f = pygame.font.SysFont("Arial", WIDTH // 50)

class Player(pygame.sprite.Sprite):
    def __init__(self, x, y, speed, sc, weapon_list):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load(getcwd() + sep + "sprites" + sep + "player.png").convert()
        self.rect = self.image.get_rect()
        if WIDTH != 800 and HEIGHT != 600:
            self.scaled_image = pygame.transform.scale(self.image, (int(self.rect.width * WIDTH / 800), int(self.rect.height * HEIGHT / 600 * 1.3)))  #Умножение на 1.3 нужно для нормального отображения
        else:
            self.scaled_image = self.image
        self.rect.x = x
        self.rect.y = y
        self.speed = speed * WIDTH / 800
        self.hp = 100
        self.armor = 50
        self.weapon_list = weapon_list
        self.weapon = None
        self.move = {"left":True, "right":True, "up":True, "down":True}
        self.sc = sc
        self.rolling = False
        self.rdelay = 100
        self.anim_delay = 0
        self.anim_num = 1
        self.anim = False

    def roll(self, mouse_pos):
        if not self.rolling and self.rdelay == 100:
            self.speedx = (-((mouse_pos[0] - self.rect.centerx) / self.gip) * (self.speed + 5)) * WIDTH / 800
            if self.speedx - int(self.speedx) >= 0.5:
                self.speedx += 1
            self.speedy = -(((mouse_pos[1] - self.rect.centery) / self.gip) * (self.speed + 5)) * WIDTH / 800
            if self.speedy - int(self.speedy) >= 0.5:
                self.speedy += 1
            self.rolling = True
            self.delay = 0
            self.rdelay = 0

    def draw_HUD(self):
        if self.rdelay < 100 and not self.rolling:
            pygame.draw.rect(self.sc, (255, 255, 255), (10, 10, int(self.rdelay * WIDTH / 800), 5))
        self.text = f.render("Здоровье: " + str(self.hp) + "     Броня: " + str(self.armor), True, (10, 5, 255))
        self.sc.blit(self.text, (10, HEIGHT - HEIGHT * 0.07))
    
    def update(self, key, mouse_pos):
        #Выбор оружия
        if key[pygame.K_1] and len(self.weapon_list) > 0:
            self.weapon = self.weapon_list[0]
        elif key[pygame.K_2] and len(self.weapon_list) > 1:
            self.weapon = self.weapon_list[1]
        elif key[pygame.K_3] and len(self.weapon_list) > 2:
            self.weapon = self.weapon_list[2]
        elif key[pygame.K_4] and len(self.weapon_list) > 3:
            self.weapon = self.weapon_list[3]
        self.gip = sqrt((mouse_pos[0] - self.rect.centerx) ** 2 + (mouse_pos[1] - self.rect.centery) ** 2)
        if self.gip == 0.0:
            self.gip = 1
        #Вычисление угла поворота
        self.angle = degrees(acos((self.rect.centerx - mouse_pos[0]) / self.gip))
        if mouse_pos[1] > self.rect.centery:
            self.angle = 360 - self.angle
        self.image = self.scaled_image
        self.image.set_colorkey((255, 255, 255))
        self.rot = pygame.transform.rotate(self.image, -self.angle)
        self.image = self.rot
        self.rect = self.image.get_rect(center=(self.rect.centerx, self.rect.centery))
        #Задержка на перекат
        if self.rdelay < 100 and not self.rolling:
            self.rdelay += 1
            
        #Изменение координат
        if not self.rolling:
            if key[pygame.K_d] and self.move["right"]:
                self.rect.x += self.speed
            if key[pygame.K_a] and self.move["left"]:
                self.rect.x -= self.speed
            if key[pygame.K_w] and self.move["up"]:
                self.rect.y -= self.speed
            if key[pygame.K_s] and self.move["down"]:
                self.rect.y += self.speed
            if key[pygame.K_SPACE]:
                self.roll(mouse_pos)
        else:
            if self.move["right"] and self.move["down"] and self.move["left"] and self.move["up"]:
                self.rect.centerx += self.speedx
                self.rect.centery += self.speedy
                self.delay += 1
                if self.delay > 20:
                    self.rolling = False
            else:
                self.rolling = False
                
            
            
