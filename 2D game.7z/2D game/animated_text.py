import pygame
from random import randint
from math import cos


pygame.font.init()

class AnimatedText:
    def __init__(self, font, size, color, text, pos):
        self.font = pygame.font.SysFont(font, size)
        self.text = self.font.render(text, True, color)
        self.rect = self.text.get_rect()
        self.pos = pos

    def render(self, sc):
        sc.blit(self.text, self.pos)


class RotatingText(AnimatedText):
    def __init__(self, font, size, color, text, pos, angle_limit):
        AnimatedText.__init__(self, font, size, color, text, pos)
        self.angle_limit = angle_limit
        self.delta_angle = 1
        self.angle = 0.1
        self.default_height = self.rect.height
        self.txt = text
        self.color = color
        self.new_color = [randint(0, 255), randint(0, 255), randint(0, 255)]
        self.delta_color = []
        for i in range(3):
            self.var = self.new_color[i] - self.color[i]
            self.var = 2 if self.var > 0 else -2
            self.delta_color.append(self.var)

    def render(self, sc):
        self.angle = cos(self.delta_angle) * self.angle_limit
        self.delta_angle += 0.05
        self.set_new_color()
        for i in range(3):
            self.color[i] += self.delta_color[i]
        self.text = self.font.render(self.txt, True, self.color)
        self.image = pygame.transform.rotate(self.text, self.angle)
        self.rect = self.image.get_rect()
        sc.blit(self.image, (self.pos[0], self.pos[1] + (self.default_height - self.rect.height) // 2))

    def set_new_color(self):
        for i in range(3):
            if self.color[i] in range(self.new_color[i] - 3, self.new_color[i] + 3):
                self.new_color[i] = randint(0, 255)
                self.var = self.new_color[i] - self.color[i]
                self.var = 2 if self.var > 0 else -2
                self.delta_color[i] = self.var
        
