def collide(rect1, rect2):
    """
    Функция для проверки столкновения двух объектов
    """
    if rect1.topright[0] in range(rect2.left, rect2.right) and rect1.topright[1]\
       in range(rect2.top, rect2.bottom) and (rect1.top in range(rect2.top, rect2.bottom) or rect1.right in range(rect2.left, rect2.right)):
        return True
    
    if rect1.topleft[0] in range(rect2.left, rect2.right) and rect1.topright[1]\
       in range(rect2.top, rect2.bottom) and (rect1.top in range(rect2.top, rect2.bottom) or rect1.left in range(rect2.left, rect2.right)):
        return True
    
    if rect1.bottomright[0] in range(rect2.left, rect2.right) and rect1.bottomright[1]\
       in range(rect2.top, rect2.bottom):
        return True
    
    if rect1.bottomleft[0] in range(rect2.left, rect2.right) and rect1.bottomright[1]\
       in range(rect2.top, rect2.bottom):
        return True

