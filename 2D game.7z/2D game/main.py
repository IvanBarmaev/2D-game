import pygame
from button import *
from arena import *
from settings import *
from pickle import load, dump
from animated_text import *
from demo import demo
from os import getcwd, sep, listdir
from level_redactor import new_arena


pygame.font.init()
stat_font = pygame.font.SysFont("Lucida Console", 14)

play_button = Button(sc, 20, HEIGHT // 10, "Играть", WIDTH // 50, None, "Начать игру")
demo_button = Button(sc, 20, HEIGHT // 10 + 5 * HEIGHT // 50, "Демо", WIDTH // 50, demo, "Запустить демонстрационный уровень")
redactor_button = Button(sc, 20, HEIGHT // 10 + 10 * HEIGHT // 50, "Редактор уровней", WIDTH // 50, demo, "Запустить редактор уровней")
stat_button = Button(sc, 20, HEIGHT // 10 + 15 * HEIGHT // 50, "Статистика", WIDTH // 50, None, "Открыть таблицу лидеров")
settings_button = Button(sc, 20, HEIGHT // 10 + 20 * HEIGHT // 50, "Настройки", WIDTH // 50, None, "Изменить настройки")
quit_button = Button(sc, 20, HEIGHT // 10 + 25 * HEIGHT // 50, "Выход", WIDTH // 50, None, "Выйти из игры")
buttons = [play_button, demo_button, redactor_button, stat_button, settings_button, quit_button]
settings_buttons = []
arenas_buttons = []
title = RotatingText("Lucida Console", 80, [255, 120, 50], "Привет", (0, 0), 5)
title_surface = pygame.Surface((title.rect.width, title.rect.height * 1.1))
description_surface = pygame.Surface((WIDTH, HEIGHT // 10))
description_font = pygame.font.SysFont("Arial", WIDTH // 50)
quit_surf = YesNoSurface(sc, WIDTH // 2 - WIDTH // 12, HEIGHT // 2 - HEIGHT // 8, WIDTH // 6, HEIGHT // 4, "Вы уверены, что хотите выйти?", WIDTH // 45)


def buttons_render():
    global buttons
    global settings_buttons
    for i in buttons:
        i.render()
    if settings_buttons:
        for i in settings_buttons:
            i.render()
    elif arenas_buttons:
        for i in arenas_buttons:
            i.render()
    pygame.display.flip()


translate = {1:"Включено", -1:"Выключено"}
resolution = [(800, 600), (1280, 720), (1600, 900), (1920, 1080)]
while True:
    if not YesNoSurface.active_surf:
        description_surface.fill((0, 0, 0))
        for i in pygame.event.get():
            if i.type == pygame.QUIT:
                pygame.quit()
            elif i.type == pygame.MOUSEBUTTONDOWN:
                key = pygame.mouse.get_pressed()
                if key[0]:
                    pos = pygame.mouse.get_pos()
                    if play_button.in_rect(*pos):
                        settings_buttons = []
                        arenas_buttons = []
                        sc.fill((0, 0, 0))
                        y = 1
                        for i in listdir(getcwd() + sep + "arenas" + sep):
                            arenas_buttons.append(Button(sc, WIDTH // 4, HEIGHT // 10 * y, i.split(".")[0], WIDTH // 50, arena))
                            y += 1
                        buttons_render()
                        
                    elif stat_button.in_rect(*pos):
                        sc.fill((0, 0, 0))
                        settings_buttons = []
                        arenas_buttons = []
                        buttons_render()
                        with open("leaderboard.data", "rb") as f:
                            leaders = load(f)
                        if len(leaders) == 0:
                            text = stat_font.render("Данных нет", True, (255, 200, 215))
                            sc.blit(text, (WIDTH // 3, HEIGHT // 10))
                        else:
                            y = 0
                            for i in leaders:
                                stats = str(i[0]) + ".  Имя: " + i[1] + ".  Время: " + i[2] + ".  Счет: " + str(i[3]) + ".  s/t: " + str(i[4])
                                text = stat_font.render(stats, True, (240, 190, 255))
                                sc.blit(text, (WIDTH // 4 + 40, HEIGHT // 10 + y))
                                y += 40
                        
                    elif settings_button.in_rect(*pos):
                        sc.fill((0, 0, 0))
                        settings_buttons = []
                        arenas_buttons = []
                        buttons_render()
                        with open("settings.data", "rb") as f:
                            param = load(f)
                        y = 0
                        for i in param:
                            if i != "Разрешение" and i != "Общая громкость":
                                settings_buttons.append(Button(sc, WIDTH // 4 , HEIGHT // 10 + y * HEIGHT // 50, i + ": " + translate[param[i]], WIDTH // 50, None, i))
                            else:
                                if i == "Разрешение":
                                    settings_buttons.append(Button(sc, WIDTH // 4, HEIGHT // 10 + y * HEIGHT // 50, i + ": " + str(param[i]),\
                                                                   WIDTH // 50, None, "Изменить разрешение окна (требуется перезапуск игры)"))
                                elif i == "Общая громкость":
                                    value = param[i]
                                    settings_buttons.append(ProgressBar(sc, WIDTH // 4, HEIGHT // 10 + y * HEIGHT // 50, WIDTH // 4, WIDTH // 50,\
                                                                        value, 1, "Общая громкость " + str(value)))
                            settings_buttons[len(settings_buttons) - 1].render()
                            y += 5
                    
                    elif quit_button.in_rect(*pos):
                        YesNoSurface.active_surf = quit_surf

                    elif demo_button.in_rect(*pos):
                        pygame.time.delay(200)
                        demo()
                        sc.fill((0, 0, 0))
                        settings_buttons = []
                        arenas_buttons = []
                        buttons_render()
                    elif redactor_button.in_rect(*pos):
                        sc.fill((0, 0, 0))
                        new_arena()
                        sc.fill((0, 0, 0))

                    elif settings_buttons:
                        for i in settings_buttons:
                            if i.in_rect(*pos):
                                if i.text != "ProgressBar":
                                    par = i.text[0:i.text.index(":")]
                                    if par != "Разрешение":
                                        param[par] *= -1
                                    else:
                                        index = resolution.index(param[par])
                                        index += 1
                                        if index >= len(resolution):
                                            index = 0
                                        param[par] = resolution[index]
                                    with open("settings.data", "wb") as f:
                                        dump(param, f)
                                    if par != "Разрешение":
                                        i.change_text(par + ": " + translate[param[par]])
                                    else:
                                        i.change_text(par + ": " + str(resolution[index]))
                                else:
                                    i.value = (pos[0] - i.x) / i.width
                                    volume = i.value
                                    value = str(i.value)[0:4]
                                    i.description = "Общая громкость " + str(value)
                                    param["Общая громкость"] = float(value)
                                    with open("settings.data", "wb") as f:
                                        dump(param, f)
                                sc.fill((0, 0, 0))
                                buttons_render()
                                break
                    elif arenas_buttons:
                        for i in arenas_buttons:
                            if i.in_rect(*pos):
                                with open(getcwd() + sep + "arenas" + sep + i.text + ".data", "rb") as f:
                                    pygame.time.delay(200)
                                    arena(*load(f))
                                    arenas_buttons = []
                                    sc.fill((0, 0, 0))
                                    buttons_render()
                                    
        pos = pygame.mouse.get_pos()
        b = buttons + settings_buttons + arenas_buttons
        for i in b:
            if i.in_rect(*pos):
                pygame.draw.rect(sc, (255, 10, 40), (i.rect.x, i.rect.y, i.rect.width - 1, i.rect.height - 1), 2)
                text = description_font.render(i.description, True, (255, 250, 10))
                description_surface.blit(text, (WIDTH // 2 - text.get_rect().width // 2, 0))
                break
        else:
            buttons_render()
        title_surface.fill((0, 0, 0))
        title.render(title_surface)
        sc.blit(title_surface, (WIDTH - WIDTH // 3, HEIGHT // 2))
        sc.blit(description_surface, (0, HEIGHT - HEIGHT // 10))
        clock.tick(30)
    else:
        quit_surf.render()
        pos = pygame.mouse.get_pos()
        num = quit_surf.in_rect(*pos)
        if num == 2:
            pygame.draw.rect(sc, (255, 10, 40), (quit_surf.yes_button.rect.x + quit_surf.x, quit_surf.yes_button.rect.y + quit_surf.y,\
                                                 quit_surf.yes_button.rect.width - 1, quit_surf.yes_button.rect.height - 1), 2)
        if num == 1:
            pygame.draw.rect(sc, (255, 10, 40), (quit_surf.no_button.rect.x + quit_surf.x, quit_surf.no_button.rect.y + quit_surf.y,\
                                                 quit_surf.no_button.rect.width - 1, quit_surf.no_button.rect.height - 1), 2)
        for i in pygame.event.get():
            if i.type == pygame.QUIT:
                pygame.quit()
            elif i.type == pygame.MOUSEBUTTONDOWN:
                if num == 2:
                    pygame.quit()
                elif num == 1:
                    YesNoSurface.active_surf = None
                    sc.fill((0, 0, 0))
        clock.tick()
    pygame.display.flip()
    pygame.display.set_caption(str(int(clock.get_fps())))
    

