import pygame
from settings import WIDTH, HEIGHT
from os import getcwd, sep
from particles import PhysObj
from random import randint

pygame.mixer.init()
class Wall(pygame.sprite.Sprite):
    index = 0
    def __init__(self, x, y, sc, group, texture):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load(getcwd() + sep + "sprites" + sep + "terrain" + sep + "walls" + sep + texture).convert()
        self.image.set_colorkey((255, 255, 255))
        self.rect = self.image.get_rect()
        if WIDTH != 800:
            self.image = pygame.transform.scale(self.image, (int(self.rect.width * WIDTH / 800), int(self.rect.height * HEIGHT / 600 * 1.3)))
        self.rect = self.image.get_rect(topleft=(x, y))
        self.add(group)
        self.hp = 0
        self.name = texture + " " + str(Wall.index)
        Wall.index += 1

    def change_size(self, width, height):
        self.image = pygame.transform.scale(self.image, (width, height))
        self.rect = self.image.get_rect(topleft=(self.rect.x, self.rect.y))



class DestructibleWall(Wall):
    def __init__(self, x, y, sc, group, destruct_group, particles_group, texture, sound, hp):
        Wall.__init__(self, x, y, sc, group, texture)
        self.sound = pygame.mixer.Sound(getcwd() + sep + "sound" + sep + sound)
        self.image.set_colorkey((255, 255, 255))
        self.sound.set_volume(0.1)
        self.hp = hp
        self.add(destruct_group)
        self.particles_group = particles_group
        self.sc = sc
    
    def hit(self, damage):
        self.hp -= damage
        self.sound.play()
        if self.hp <= 0:
            self.angle = randint(0, 360)
            PhysObj(self.sc, self.particles_group, "piece_of_wall.png", self.rect.centerx, self.rect.centery, 5, self.angle, randint(2, 6), 0)
            PhysObj(self.sc, self.particles_group, "piece_of_wall.png", self.rect.centerx, self.rect.centery, 5, self.angle - 180, randint(2, 6), 0)
            self.kill()
